import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TemplateRoutingModule } from './template-routing.module';

import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { TemplateComponent } from './template.component';
import { HomeComponent } from './../home/home.component';
import { ContactUsComponent } from './../contact-us/contact-us.component';
import { LoginComponent } from './../auth/login/login.component';
import { BookAppointmentComponent } from './../book-appointment/book-appointment.component';

import { AuthModule } from './../auth/auth.module';
import { CoreModule } from './../core/core.module';

import { TemplateService } from './template.service';

@NgModule({
  declarations: [
    TemplateComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ContactUsComponent,
    LoginComponent,
    BookAppointmentComponent
  ],
  imports: [
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    TemplateRoutingModule,
    AuthModule,
    CoreModule
  ],
  exports: [LoginComponent],
  providers: [TemplateService]
})
export class TemplateModule { }
