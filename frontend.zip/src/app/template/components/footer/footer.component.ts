import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';

import { TemplateService } from './../../template.service';
import * as M from "node_modules/materialize-css/dist/js/materialize";

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  newsLetterForm: FormGroup;
  submitted = false;

  constructor(private fb: FormBuilder,
              private templateService: TemplateService) { this.createForm(); }

  ngOnInit(): void {
  }

  createForm() {
    this.newsLetterForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  onSubmit(){
    this.submitted = true;
     M.Toast.dismissAll();
    if(this.newsLetterForm.valid){
      this.templateService.newsLetter(this.newsLetterForm.value)
        .subscribe(data => {
          this.newsLetterForm.reset();
          M.toast({html: `<span>${data.message}</span><button class="btn-flat toast-action">${data.status}</button>`});
        }, err => {
          M.toast({html: `<span>${err.message}</span><button class="btn-flat toast-action">error</button>`});
        });
    }
  }

}
