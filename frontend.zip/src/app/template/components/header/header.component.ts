import {
  Component,
  OnInit,
  ViewChild,
  ElementRef
} from "@angular/core";
import * as M from "node_modules/materialize-css/dist/js/materialize";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @ViewChild('sidenav') sidenav: ElementRef;
  constructor() { }

  ngOnInit(): void {
  }

  sideNav(){
    // var elems = document.querySelectorAll('.sidenav');
    // var instances = M.Sidenav.init(elems, options);
    M.Sidenav.init(this.sidenav.nativeElement, {});
  }

  loginModal(){
    const elem = document.getElementById('loginModal');
    const instance = M.Modal.init(elem, {dismissible: false});
    instance.open();
  }
}
