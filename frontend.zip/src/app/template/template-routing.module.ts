import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TemplateComponent } from './template.component';
import { HomeComponent } from './../home/home.component';
import { ContactUsComponent } from './../contact-us/contact-us.component';
import { BookAppointmentComponent } from './../book-appointment/book-appointment.component';
import { RegisterComponent } from './../auth/register/register.component';
import { ForgotPasswordComponent } from './../auth/forgot-password/forgot-password.component';
import { ConfirmationComponent } from './../auth/confirmation/confirmation.component';
import { NoAuthGuardService } from './../core/services/no-auth-guard.service';
import { ResetPasswordComponent } from './../auth/reset-password/reset-password.component';

const routes: Routes = [
  { path: '' , component: TemplateComponent,
  children: [
    { path: '' , component: HomeComponent},
    { path: 'contact-us' , component: ContactUsComponent},
    { path: 'book-appointment' , component: BookAppointmentComponent},
    { path: 'register' , component: RegisterComponent, canActivate:[NoAuthGuardService]},
    { path: 'confirmation/:id' , component: ConfirmationComponent, canActivate:[NoAuthGuardService]},
    { path: 'forgot-password' , component: ForgotPasswordComponent, canActivate:[NoAuthGuardService]},
    { path: 'reset-password/:token' , component: ResetPasswordComponent, canActivate:[NoAuthGuardService]}
  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TemplateRoutingModule { }
