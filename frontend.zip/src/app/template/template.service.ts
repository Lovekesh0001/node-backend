import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { environment } from './../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TemplateService {

  constructor(private http: HttpClient) { }

  newsLetter(body: {email: string }): Observable<{status: string, message: string}>{
    return this.http.post<{status: string, message: string}>(`${ environment.backend_url }/api/newsletter`, body);
  }

  contactUs(body: any): Observable<{status: string, message: string}>{
    return this.http.post<{status: string, message: string}>(`${ environment.backend_url }/api/contact-us`, body);
  }

  bookAppointment(body: any): Observable<{status: string, message: string}>{
    return this.http.post<{status: string, message: string}>(`${ environment.backend_url }/api/book-appointment`, body);
  }
}
