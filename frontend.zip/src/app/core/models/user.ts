export class User {
    _id: string;
    email: string;
    password: string;
}

export class UserLoginRes {
    message: string;
    status: string;
    token: string;
}

export class SignUpRes {
    message: string;
    status: string;
}