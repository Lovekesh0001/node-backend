import { Observable, of as ObservableOf } from 'rxjs';
import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { RouterStateSnapshot } from '@angular/router';
import { ActivatedRouteSnapshot } from '@angular/router';
import { JwtService } from './jwt.service';
import { CanActivate, Router, CanActivateChild } from '@angular/router';
import { map, catchError } from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(
    private jwtService: JwtService,
    private router: Router,
    private authService: AuthService) { }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<any> {
    //  if (this.jwtService.getToken()) {
    //     return ObservableOf(true);
    //  }
    const token = route.queryParamMap.get('token');
     if(token || this.jwtService.getToken()){
      return this.authService.isAuthenticate(token).pipe(
        map(authenticate => {
          if(authenticate === true){
              if(token){
                this.jwtService.setToken(token);
              }
            //this.router.navigate(['/']);
            return true;
          }
          this.router.navigate(['/']);
          return false;
        }),catchError(err => {
          this.router.navigate(['/']);
          return ObservableOf(false);
        })
      );
     }else{
      this.router.navigate(['/'])
      return ObservableOf(false);
    }
  }
  canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean>{
    return this.canActivate(route, state);
  }
}
