import { JwtService } from './jwt.service';
import { Injectable } from '@angular/core';
import { CanActivate, Router, CanActivateChild } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class NoAuthGuardService implements CanActivate {

  constructor(private jwtService: JwtService,private router: Router) { }

  canActivate(): boolean {
    if (this.jwtService.getToken()) {
      this.router.navigate(['/'])
      return false;
    }
    else {
      return true;
    }
  }
}
