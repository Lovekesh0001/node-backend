import { Observable } from 'rxjs';
import { User, UserLoginRes, SignUpRes } from '../models/user';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from './../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  login(body: User): Observable<UserLoginRes>{
    return this.http.post<UserLoginRes>(`${environment.base_url}/users/login`, body);
  }

  signup(body: User): Observable<SignUpRes>{
    return this.http.post<SignUpRes>(`${environment.base_url}/users/signup`, body);
  }

  confirmation(id): Observable<{status: string, message: string}>{
    return this.http.get<{status: string, message: string}>(`${environment.base_url}/users/confimation/${id}`);
  }

  forgotPassword(body: {email: string}): Observable<{status: string, message: string}>{
    return this.http.post<{status: string, message: string}>(`${environment.base_url}/users/forgot-password`, body);
  }

  resetPassword(body, token): Observable<{status: string, message: string}>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      'Authorization': `bearer ${token}`
      })
    }
    return this.http.put<{status: string, message: string}>(`${environment.base_url}/users/reset-password`, body, httpOptions);
  }

  isAuthenticate(token): Observable<boolean>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      'Authorization': `bearer ${token}`
      })
    }
    return this.http.get<boolean>(`${environment.base_url}/auth/authenticate`, httpOptions);
  }

  logout(): Observable<boolean>{
    return this.http.get<boolean>(`${environment.base_url}/auth/logout`);
  }

}
