import {
  Component,
  OnInit,
  AfterViewInit,
  ViewChild,
  ElementRef
} from "@angular/core";
import * as M from "node_modules/materialize-css/dist/js/materialize";
import { environment } from './../../environments/environment';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, AfterViewInit {
  @ViewChild('carousel') carousel: ElementRef;
  url = environment.backend_url;
  constructor() { }

  ngOnInit(): void {
  }

  ngAfterViewInit(){
      let iCarousel = new M.Carousel(this.carousel.nativeElement, {
      fullWidth: true,
      indicators: true
  });

    // this did the trick
    setInterval(() => {
      iCarousel.next();
    }, 5000)
  }

}
