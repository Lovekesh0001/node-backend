import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { JwtService } from './../core/services/jwt.service';
import { TemplateService } from './../template/template.service';
import * as M from "node_modules/materialize-css/dist/js/materialize";
import { environment } from './../../environments/environment';

@Component({
  selector: 'app-book-appointment',
  templateUrl: './book-appointment.component.html',
  styleUrls: ['./book-appointment.component.css']
})
export class BookAppointmentComponent implements OnInit {
  bookAppointmentForm: FormGroup;
  submitted = false;
  isProgress = false;
  url = environment.backend_url;

  constructor(private fb: FormBuilder,
              private router: Router,
              private jwtService: JwtService,
              private templateService: TemplateService) { this.createForm(); }

  ngOnInit(): void {
  }

  createForm() {
    this.bookAppointmentForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phonenumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      servicename: ['', Validators.required],
      message: ['']
    });
  }


  onSubmit(){
    if(this.jwtService.getToken()){
      M.Toast.dismissAll();
      this.submitted = true;
      if(this.bookAppointmentForm.valid){
        this.isProgress = true;
        this.templateService.bookAppointment(this.bookAppointmentForm.value)
        .subscribe(data => {
          this.isProgress = false;
          this.submitted = false;
          if(data.status === 'success'){
            this.bookAppointmentForm.reset();
          }
            M.toast({html: `<span>${data.message}</span><button class="btn-flat toast-action">${data.status}</button>`});
        }, err => {
          this.isProgress = false;
          this.submitted = false;
          M.toast({html: `<span>${err.message}</span><button class="btn-flat toast-action">error</button>`});
        });
      }
    }else{
      const elem = document.getElementById('loginModal');
      const instance = M.Modal.init(elem, {dismissible: false});
      instance.open();
    }
  }

}
