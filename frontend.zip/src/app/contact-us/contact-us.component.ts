import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { JwtService } from './../core/services/jwt.service';
import { TemplateService } from './../template/template.service';
import * as M from "node_modules/materialize-css/dist/js/materialize";

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {
  contactUsForm: FormGroup;
  submitted = false;
  isProgress = false;

  constructor(private fb: FormBuilder,
              private router: Router,
              private jwtService: JwtService,
              private templateService: TemplateService) { this.createForm(); }

  ngOnInit(): void {
  }

  createForm() {
    this.contactUsForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phonenumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      subject: [''],
      message: ['']
    });
  }


  onSubmit(){
    if(this.jwtService.getToken()){
      M.Toast.dismissAll();
      this.submitted = true;
      if(this.contactUsForm.valid){
        this.isProgress = true;
        this.templateService.contactUs(this.contactUsForm.value)
        .subscribe(data => {
          this.isProgress = false;
          this.submitted = false;
          if(data.status === 'success'){
            this.contactUsForm.reset();
          }
            M.toast({html: `<span>${data.message}</span><button class="btn-flat toast-action">${data.status}</button>`});
        }, err => {
          this.isProgress = false;
          this.submitted = false;
          M.toast({html: `<span>${err.message}</span><button class="btn-flat toast-action">error</button>`});
        });
      }
    }else{
      const elem = document.getElementById('loginModal');
      const instance = M.Modal.init(elem, {dismissible: false});
      instance.open();
    }
  }

}
