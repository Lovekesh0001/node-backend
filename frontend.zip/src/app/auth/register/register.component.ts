import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { AuthService } from './../../core/services/auth.service';
import { MustMatch } from 'src/app/admin/helper/must-match.validator';
import * as M from "node_modules/materialize-css/dist/js/materialize";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  signupForm: FormGroup;
  submitted = false;
  isProgress = false;
  passwordIcon = "visibility";

  constructor(private fb: FormBuilder,
              private authService: AuthService,
              private router: Router) { this.createForm(); }

  ngOnInit(): void {
  }

  createForm() {
    this.signupForm = this.fb.group({
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    }, { validator: MustMatch('password', 'confirmPassword')});
  }

  onSubmit(){
    M.Toast.dismissAll();
    this.submitted = true;
    if(this.signupForm.valid){
      this.isProgress = true;
      this.authService.signup(this.signupForm.value)
        .subscribe(data => {
          this.isProgress = false;
          if(data.status === 'success'){
            this.router.navigateByUrl("/");
          }
          M.toast({html: `<span>${data.message}</span><button class="btn-flat toast-action">${data.status}</button>`});
        }, err => {
          this.isProgress = false;
         M.toast({html: `<span>${err.message}</span><button class="btn-flat toast-action">error</button>`});
        });
    }
  }  

  showHidePass(event){
    if(event.type === 'password'){
      event.type = 'text';
      this.passwordIcon = "visibility_off";
    }else{
      this.passwordIcon = "visibility";
      event.type = 'password';
    }
  }

  openLoginModal(){
    const elem = document.getElementById('loginModal');
    const instance = M.Modal.init(elem, {dismissible: false});
    instance.open();
  }

}
