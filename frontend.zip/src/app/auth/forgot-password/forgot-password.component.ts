import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AuthService } from './../../core/services/auth.service';
import * as M from "node_modules/materialize-css/dist/js/materialize";

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup;
  submitted = false;
  isProgress = false;

  constructor(private fb: FormBuilder,
              private cookieService: CookieService,
              private authService: AuthService,
              private router: Router) { 
                this.createForm();
              }

  ngOnInit(): void {
  }

  createForm() {
    this.forgotPasswordForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

   onSubmit(){
     M.Toast.dismissAll();
    this.submitted = true;
    if(this.forgotPasswordForm.valid){
      this.isProgress = true;
      this.authService.forgotPassword(this.forgotPasswordForm.value)
        .subscribe(data => {
          this.isProgress = false;
          if(data.status === 'success'){
            this.router.navigateByUrl("/");
          }
          M.toast({html: `<span>${data.message}</span><button class="btn-flat toast-action">${data.status}</button>`});
        }, err => {
          this.isProgress = false;
          M.toast({html: `<span>${err.message}</span><button class="btn-flat toast-action">error</button>`});
        });
    }
  }

}
