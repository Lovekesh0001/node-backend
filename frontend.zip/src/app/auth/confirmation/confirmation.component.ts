import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from './../../core/services/auth.service';
import * as M from "node_modules/materialize-css/dist/js/materialize";

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationComponent implements OnInit {
  id: string = '';

  constructor(
    private authService: AuthService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
   ) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.id = params['id'];
      if(!this.id){
        this.router.navigateByUrl("/");
      }else{
        this.confirmation();
      }
    });
  }

  confirmation(){
    M.Toast.dismissAll();
    this.authService.confirmation(this.id)
      .subscribe(data => {
        this.router.navigateByUrl("/");
        M.toast({html: `<span>${data.message}</span><button class="btn-flat toast-action">${data.status}</button>`});
      },err => {
        M.toast({html: `<span>${err.message}</span><button class="btn-flat toast-action">error</button>`});
      });
  }

}
