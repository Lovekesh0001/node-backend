import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AuthService } from './../../core/services/auth.service';
import { JwtService } from './../../core/services/jwt.service';
import * as M from "node_modules/materialize-css/dist/js/materialize";
import { environment } from './../../../environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  checked = false;
  loginForm: FormGroup;
  submitted = false;
  isProgress = false;
  passwordIcon = "visibility";
  url = environment.backend_url;

  constructor(private fb: FormBuilder,
              private cookieService: CookieService,
              private authService: AuthService,
              private router: Router,
              private jwtService: JwtService) {
              this.createForm();
              const cookieExists: boolean = cookieService.check('email');
                if(cookieExists){
                  this.checked = true;
                  this.loginForm.patchValue({
                    email: this.cookieService.get('email'),
                    password: this.cookieService.get('password'),
                  });
                }
              }

  ngOnInit(): void {
  }

  createForm() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit(){
    M.Toast.dismissAll();
    this.submitted = true;
    if(this.loginForm.valid){
      this.isProgress = true;
      this.authService.login(this.loginForm.value)
        .subscribe(data => {
          this.isProgress = false;
          if(data.status === 'success'){
            this.closeModal();
            //this.router.navigateByUrl("/admin");
            this.jwtService.setToken(data.token);
             if(this.checked == true){
                this.cookieService.set('checked', "checked");
                this.cookieService.set('email', this.loginForm.value.email);
                this.cookieService.set('password', this.loginForm.value.password);
              }else{
                this.cookieService.delete('checked');
                this.cookieService.delete('email');
                this.cookieService.delete('password');
              }
          }
            M.toast({html: `<span>${data.message}</span><button class="btn-flat toast-action">${data.status}</button>`});
        }, err => {
          this.isProgress = false;
          M.toast({html: `<span>${err.message}</span><button class="btn-flat toast-action">error</button>`});
        });
    }
  }

  remeberMe(event){
    if(this.checked == false){
      this.checked = true;
    }else{
      this.checked = false;
    }
  }

  showHidePass(event){
    if(event.type === 'password'){
      event.type = 'text';
      this.passwordIcon = "visibility_off";
    }else{
      this.passwordIcon = "visibility";
      event.type = 'password';
    }
  }

  closeModal(){
    const body = document.querySelector('body');
    body.style.overflow = '';
    const elem = document.getElementById('loginModal');
    const instance = M.Modal.init(elem, {});
    instance.close();
  }

  forgotPassword(){
    this.closeModal();
    this.router.navigateByUrl("/forgot-password");
  }

  register(){
    this.closeModal();
    this.router.navigateByUrl("/register");
  }

  closeLoginModal(){
    this.closeModal();
  }

}
