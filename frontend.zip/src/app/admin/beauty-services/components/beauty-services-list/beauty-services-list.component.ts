import { Component, OnInit, ViewChild, AfterViewInit } from "@angular/core";
import { BeautyServices } from './../../models/beauty-services';
import { BeautyServicesService } from './../../services/beauty-services.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { DeleteDialogBoxComponent } from './../../../helper/delete-dialog-box/delete-dialog-box.component';
import { ErrorHandlerService } from './../../../helper/error-handler.service';
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";

@Component({
  selector: 'app-beauty-services-list',
  templateUrl: './beauty-services-list.component.html',
  styleUrls: ['./beauty-services-list.component.css']
})
export class BeautyServicesListComponent implements OnInit {
  breadcrumb = [{name1:"Admin", link1:"/admin"},{name1:"Services Listings", link1:"/admin/services"}]
  displayedColumns = ['name', 'shortdescription', 'added', 'updated', 'action'];
  
  dataSource: BeautyServices[] = [];
  // pagination
  length = 0;
  page = 1;
  perPage = 10;
  sortField = '';
  sortDir = '';
  isDataLoading = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private beautyServicesService:BeautyServicesService,
              public dialog: MatDialog,
              private errorHandlerService: ErrorHandlerService,) { }

  ngOnInit(): void {
    this.getBeautyServices(this.page, this.perPage, this.sortField, this.sortDir, '');
  }

  ngAfterViewInit() {
    this.paginator.page.subscribe(data => {
      this.isDataLoading = true;
      this.getBeautyServices(this.page=++data.pageIndex, this.perPage=data.pageSize, this.sortField, this.sortDir, '');
    });

    this.sort.sortChange.subscribe(data => {
      this.paginator.pageIndex= 0;
      this.isDataLoading = true;
      this.getBeautyServices(1, 10, data.active, data.direction,'');
    });
  }

  filterData(value: string){
    this.paginator.pageIndex= 0;
      this.isDataLoading = true;
      this.getBeautyServices(1, 10, '', '', value.trim());
  }

  getBeautyServices(page, perPage, sortField, sortDir, filter) {
    this.beautyServicesService.getBeautyServices(page, perPage, sortField, sortDir, filter)
                              .subscribe(data => {
                                this.isDataLoading = false;
                                if(data){
                                  this.dataSource = data.docs;
                                  this.length = data.total;
                                }
                              }, err => {
                                this.errorHandlerService.error(err);
                              });
  }

  deleteDialog(id: string) {
    const dialogRef = this.dialog.open(DeleteDialogBoxComponent, {
      data:{
        message: 'Are you sure want to delete?',
        confirmButtonText: 'Delete',
        cancelButtonText: 'No Thanks',
        id:id
      },
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(id => {
      if(id) {
        this.deleteRowData(id);
      }
    });
  }

  deleteRowData(id){
    this.beautyServicesService.deleteBeautyServiceById(id)
        .subscribe((data: any) => {
         if(data.status == 'success'){
            this.length = this.length-1;
            this.dataSource = this.dataSource.filter((value,key)=>{
              return value._id != id;
            });
         }
        this.errorHandlerService.success(data.message, data.status);
        }, err => {
          this.errorHandlerService.error(err);
        });
  }

}