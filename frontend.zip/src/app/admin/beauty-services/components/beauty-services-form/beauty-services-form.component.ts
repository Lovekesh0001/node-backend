import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import {MatSnackBar} from '@angular/material/snack-bar';
import { ErrorHandlerService } from "src/app/admin/helper/error-handler.service";
import { BeautyServicesService } from './../../services/beauty-services.service';
import { BeautyServices } from './../../models/beauty-services';

@Component({
  selector: 'app-beauty-services-form',
  templateUrl: './beauty-services-form.component.html',
  styleUrls: ['./beauty-services-form.component.css']
})
export class BeautyServicesFormComponent implements OnInit {
  breadcrumb = [];
  public Editor = ClassicEditor;
  beautyServicsForm: FormGroup;
  submitted = false;
  private beautyServices: BeautyServices;
  id: string = '';
  addUpdateName = 'Add Service';

  constructor(
            private fb: FormBuilder,
            private snackBar: MatSnackBar,
            private errorHandlerService: ErrorHandlerService,
            private beautyServicesService: BeautyServicesService,
            private router: Router,
            private activatedRoute: ActivatedRoute
           ) { }

  ngOnInit(): void {
    this.getParamsId();
    this.createForm();
    this.breadcrumb = [{name1:"Admin", link1:"/admin"},{name1:"Services Listings", link1:"/admin/services"},{name1:this.addUpdateName, link1:""}]
  }

  getParamsId(){
     this.activatedRoute.params.subscribe(params => {
      this.id = params['id'];
      if(this.id){
        this.setServiceToForm();
        this.addUpdateName = 'Update Service';
      }
     });
  }

  setServiceToForm(){
        this.beautyServicesService.getBeautyServiceById(this.id)
        .subscribe((data: any) => {
         if(data.status == 'success'){
            this.beautyServices = data.data;
            this.beautyServicsForm.patchValue(this.beautyServices);
         }else{
           this.errorHandlerService.success(data.message, data.status);
           this.router.navigateByUrl("/admin/services");
         }
        }, err => {
          this.errorHandlerService.error(err);
        });
  }

  createForm() {
    this.beautyServicsForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      shortdescription: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  onSubmit(){
    this.submitted = true;
    if(!this.beautyServicsForm.valid){
      return false;
    }else{
      if(this.id){
        this.update();
      }else{
        this.create();
      }
    }
  }

  private create() {
    this.beautyServicesService.createBeautyService(this.beautyServicsForm.value)
        .subscribe((data: any) => {
         this.errorHandlerService.success(data.message, data.status);
         if(data.status == 'success'){
            this.router.navigateByUrl("/admin/services");
         }
      }, err => {
        this.errorHandlerService.error(err);
      });
  }

  private update() {
    this.beautyServicesService.updateBeautyService(this.id, this.beautyServicsForm.value)
        .subscribe((data: any) => {
         this.errorHandlerService.success(data.message, data.status);
         if(data.status == 'success'){
            this.router.navigateByUrl("/admin/services");
         }
      }, err => {
        this.errorHandlerService.error(err);
      });
  }

}
