import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BeautyServices, BeautyServicesPaginate } from './../models/beauty-services';
import { environment } from './../../../../environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BeautyServicesService {

  constructor(private http: HttpClient) { }

  getBeautyServices(page, perPage, sortField, sortDir, filter):Observable<BeautyServicesPaginate> {
    let queryString = `${environment.base_url}/services?page=${page}&perPage=${perPage}`;
    if(sortField && sortDir){
      queryString = `${queryString}&sortField=${sortField}&sortDir=${sortDir}`;
    }
    if(filter){
      queryString = `${queryString}&filter=${filter}`;
    }
    return this.http.get<BeautyServicesPaginate>(queryString);
  }

  createBeautyService(data):Observable<BeautyServices>{
    return this.http.post<BeautyServices>(`${environment.base_url}/services`, data);
  }

  updateBeautyService(id, data):Observable<BeautyServices>{
    return this.http.put<BeautyServices>(`${environment.base_url}/services/${id}`, data);
  }

  getBeautyServiceById(id):Observable<BeautyServices[]> {
    return this.http.get<BeautyServices[]>(`${environment.base_url}/services/${id}`);
  }

  deleteBeautyServiceById(id):Observable<BeautyServices[]> {
    return this.http.delete<BeautyServices[]>(`${environment.base_url}/services/${id}`);
  }

  uploadBeautyServiceImages(formData, id) {
    return this.http.post(`${environment.base_url}/services/upload/${id}`, formData, {
        reportProgress: true,
        observe: "events"
      });
  }

  getUploadBeautyServiceImages(id) {
    return this.http.get(`${environment.base_url}/services/upload/${id}`);
  }

  deleteUploadBeautyServiceImages(ids, serviceId) {
    return this.http.post(`${environment.base_url}/services/upload`, {ids:ids, serviceId:serviceId});
  }

  updateBeautyServiceImagesCaption(captions) {
    return this.http.post(`${environment.base_url}/services/caption`, {captions:captions});
  }

  updateBeautyServicesortPosition(currentIndex, previousIndex, imagesid, id) {
    return this.http.post(`${environment.base_url}/services/caption/${id}`, {currentIndex:currentIndex, previousIndex:previousIndex, imagesid:imagesid});
  }
}
