import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MaterialModule } from './../../shared/material.module';
import { BeautyServicesListComponent } from './components/beauty-services-list/beauty-services-list.component';
import { BeautyServicesService } from './services/beauty-services.service';
import { BeautyServicesFormComponent } from './components/beauty-services-form/beauty-services-form.component';
import { BeautyServicesImagesComponent } from './components/beauty-services-images/beauty-services-images.component';

@NgModule({
  declarations: [
    BeautyServicesListComponent,
    BeautyServicesFormComponent,
    BeautyServicesImagesComponent],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [BeautyServicesService]
})
export class BeautyServicesModule { }
