export class BeautyServices {
    _id: string;
    name: string;
    shortdescription: string;
    description: string;
    added: Date;
    updated: Date;
}

export class BeautyServicesPaginate {
    docs: BeautyServices[];
    total: number;
    limit: number;
    page: number;
    pages: number;
}
