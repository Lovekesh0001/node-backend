import { Component, OnInit, Inject, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-dialog-box',
  templateUrl: './delete-dialog-box.component.html',
  styleUrls: ['./delete-dialog-box.component.css']
})
export class DeleteDialogBoxComponent implements OnInit {
  message: string;
  confirmButtonText: string;
  cancelButtonText: string;
  id: string;

  constructor(public dialogRef: MatDialogRef<DeleteDialogBoxComponent>,
              @Optional() @Inject(MAT_DIALOG_DATA) public data: any) 
              { 
                this.message = data.message;
                this.confirmButtonText = data.confirmButtonText;
                this.cancelButtonText = data.cancelButtonText;
                this.id = data.id;
              }

  ngOnInit(): void {
  }

  onConfirmClick(): void {
    this.dialogRef.close(this.id);
  }

  closeDialog(){
    this.dialogRef.close();
  }

}
