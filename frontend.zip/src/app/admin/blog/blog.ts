export class Blog {
    _id: string;
    name: string;
    description: string;
    added: Date;
    updated: Date;
}

export class BlogPaginate {
    docs: Blog[];
    total: number;
    limit: number;
    page: number;
    pages: number;
}
