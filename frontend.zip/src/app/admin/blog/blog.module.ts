import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { MaterialModule } from './../../shared/material.module';

import { BlogListComponent } from './components/blog-list/blog-list.component';
import { BlogFormComponent } from './components/blog-form/blog-form.component';
import { BlogImagesComponent } from './components/blog-images/blog-images.component';
import { BlogService } from './blog.service';
@NgModule({
  declarations: [BlogListComponent, BlogFormComponent, BlogImagesComponent],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [BlogService]
})
export class BlogModule { }
