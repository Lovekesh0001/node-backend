import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import {MatSnackBar} from '@angular/material/snack-bar';
import { ErrorHandlerService } from "src/app/admin/helper/error-handler.service";
import { BlogService } from './../../blog.service';
import { Blog } from './../../blog';

@Component({
  selector: 'app-blog-form',
  templateUrl: './blog-form.component.html',
  styleUrls: ['./blog-form.component.css']
})
export class BlogFormComponent implements OnInit {
  breadcrumb = [];
  public Editor = ClassicEditor;
  blogForm: FormGroup;
  submitted = false;
  private blog: Blog;
  id: string = '';
  addUpdateName = 'Add Blog';

  constructor(private fb: FormBuilder,
            private snackBar: MatSnackBar,
            private errorHandlerService: ErrorHandlerService,
            private blogService: BlogService,
            private router: Router,
            private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.getParamsId();
    this.createForm();
    this.breadcrumb = [{name1:"Admin", link1:"/admin"},{name1:"Blog Listings", link1:"/admin/blog"},{name1:this.addUpdateName, link1:""}]
  }

  getParamsId(){
     this.activatedRoute.params.subscribe(params => {
      this.id = params['id'];
      if(this.id){
        this.setServiceToForm();
        this.addUpdateName = 'Update Blog';
      }
     });
  }

  setServiceToForm(){
        this.blogService.getBlogById(this.id)
        .subscribe((data: any) => {
         if(data.status == 'success'){
            this.blog = data.data;
            this.blogForm.patchValue(this.blog);
         }else{
           this.errorHandlerService.success(data.message, data.status);
           this.router.navigateByUrl("/admin/blog");
         }
        }, err => {
          this.errorHandlerService.error(err);
        });
  }

  createForm() {
    this.blogForm = this.fb.group({
      name: [''],
      description: ['']
    });
  }

  onSubmit(){
    this.submitted = true;
    if(!this.blogForm.valid){
      return false;
    }else{
      if(this.id){
        this.update();
      }else{
        this.create();
      }
    }
  }

  private create() {
    this.blogService.createBlog(this.blogForm.value)
        .subscribe((data: any) => {
         this.errorHandlerService.success(data.message, data.status);
         if(data.status == 'success'){
            this.router.navigateByUrl("/admin/blog");
         }
      }, err => {
        this.errorHandlerService.error(err);
      });
  }

  private update() {
    this.blogService.updateBlog(this.id, this.blogForm.value)
        .subscribe((data: any) => {
         this.errorHandlerService.success(data.message, data.status);
         if(data.status == 'success'){
            this.router.navigateByUrl("/admin/blog");
         }
      }, err => {
        this.errorHandlerService.error(err);
      });
  }

}
