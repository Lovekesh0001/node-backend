import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpEventType, HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';  
import { catchError, map } from 'rxjs/operators'; 
import { BlogService } from './../../blog.service';
import { ErrorHandlerService } from "src/app/admin/helper/error-handler.service";
import { DeleteDialogBoxComponent } from './../../../helper/delete-dialog-box/delete-dialog-box.component';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-blog-images',
  templateUrl: './blog-images.component.html',
  styleUrls: ['./blog-images.component.css']
})
export class BlogImagesComponent implements OnInit {
  breadcrumb = [];
  id: string = '';
  dataSource = [];
  progress:number = 1;
  images = {};
  ids = [];
  checkboxIds = [];
  selectedAllcheckBox = false;

  constructor(private router: Router,
              private activatedRoute: ActivatedRoute,
              private blogService: BlogService,
              private errorHandlerService: ErrorHandlerService,
              public dialog: MatDialog) { }

  ngOnInit(): void {
    this.getParamsId();
    this.getUploadBlogImages();
    this.breadcrumb = [{name1:"Admin", link1:"/admin"},{name1:"Blog Listings", link1:"/admin/blog"},{name1:"Update Blog", link1:`/admin/blog/edit/${this.id}`},{name1:"Images", link1:""}]
  }

  getParamsId() {
    this.activatedRoute.params.subscribe((params) => {
      this.id = params['id'];
    });
  }

  getUploadBlogImages(){
    this.blogService.getUploadBlogImages(this.id).
      subscribe((data: any) => {
        if(data.status == 'success'){
          this.dataSource = data.data;
        }
      });
  }

  handleFileUpload(files: File[]) {
    this.progress = 1;  
    var files: File[]
    if (files && files[0]) {
      var formData = new FormData();
      Array.from(files).forEach(f => formData.append('images', f))
      this.images = formData;
      // var filesAmount = files.length; 
      // for (let i = 0; i < filesAmount; i++) {
      //   var reader = new FileReader();
      //   reader.onload = (event:any) => {
      //       this.imageUrls.push(event.target.result); 
      //   }
      //   reader.readAsDataURL(files[i]);
      // }
    }
  }

  saveImages(){
    this.blogService.uploadBlogeImages(this.images, this.id).pipe(  
      map(event => {  
        switch (event.type) {  
          case HttpEventType.UploadProgress:  
            this.progress = Math.round(event.loaded * 100 / event.total);  
            break;  
          case HttpEventType.Response:  
            return event;  
        }  
      }),  
      catchError((error: HttpErrorResponse) => {  
        this.progress = 1;  
        return of(`${error} upload failed.`);  
      })).subscribe((data: any) => {  
        if (typeof (data) === 'object') {  
          this.images = [];
          this.errorHandlerService.success(data.body.message, data.body.status);
          if(data.body.status === 'error'){
            this.progress = 1;
          }
        }  
      });
  }

  refreshGalleryImages(){
    this.getUploadBlogImages();
    this.errorHandlerService.success("Successfully refresh ", "Success");
    this.progress = 1;
  }

  deleteImage(id: string){
    this.ids.push(id);
    this.deleteUploadBlogImages(id);
  }

  updateCheckBox(id: string, event) {
    if(event === true){
      this.checkboxIds.push(id);
    }else{
      let index = this.checkboxIds.indexOf(id);
      this.checkboxIds.splice(index, 1);
    };
  }

  selectAllCheckBox(event) {
    if(event == true){
      for(var j=0; j < this.dataSource.length; j++) {
      this.selectedAllcheckBox = true;
      this.checkboxIds.push(this.dataSource[j]._id );
     }
    }else{
      this.selectedAllcheckBox = false;
       this.checkboxIds = [];
    }
  }

  deleteAllImageButton(){
    this.deleteUploadBlogImages(this.checkboxIds);
  }

  deleteUploadBlogImages(ids){
    if(ids.length > 0){
      const dialogRef = this.dialog.open(DeleteDialogBoxComponent, {
      data:{
        message: 'Are you sure want to delete?',
        confirmButtonText: 'Delete',
        cancelButtonText: 'No Thanks',
        id:ids
      },
      width: '250px',
    });

    dialogRef.afterClosed().subscribe(id => {
      this.checkboxIds = [];
      this.ids = [];
      if(id) {
         this.blogService.deleteUploadBlogImages(id, this.id).
              subscribe((data: any) => {
              if(data.status == 'success'){
                this.getUploadBlogImages();
              }
              this.errorHandlerService.success(data.message, data.status);
            },err => this.errorHandlerService.error(err));
      }
    });
    }else{
      this.errorHandlerService.success("Please select images to delete", "Error");
    }
  }

}
