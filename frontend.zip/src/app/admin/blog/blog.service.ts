import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Blog, BlogPaginate } from './blog';
import { environment } from './../../../environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BlogService {

  constructor(private http: HttpClient) { }

  getBlogs(page, perPage, sortField, sortDir, filter):Observable<BlogPaginate> {
    let queryString = `${environment.base_url}/blog?page=${page}&perPage=${perPage}`;
    if(sortField && sortDir){
      queryString = `${queryString}&sortField=${sortField}&sortDir=${sortDir}`;
    }
    if(filter){
      queryString = `${queryString}&filter=${filter}`;
    }
    return this.http.get<BlogPaginate>(queryString);
  }

  deleteBlogById(id):Observable<Blog[]> {
    return this.http.delete<Blog[]>(`${environment.base_url}/blog/${id}`);
  }

  getBlogById(id):Observable<Blog[]> {
    return this.http.get<Blog[]>(`${environment.base_url}/blog/${id}`);
  }

  createBlog(data):Observable<Blog>{
    return this.http.post<Blog>(`${environment.base_url}/blog`, data);
  }

  updateBlog(id, data):Observable<Blog>{
    return this.http.put<Blog>(`${environment.base_url}/blog/${id}`, data);
  }

  // blog images
  uploadBlogeImages(formData, id) {
    return this.http.post(`${environment.base_url}/blog/upload/${id}`, formData, {
        reportProgress: true,
        observe: "events"
      });
  }

  getUploadBlogImages(id) {
    return this.http.get(`${environment.base_url}/blog/upload/${id}`);
  }

  deleteUploadBlogImages(ids, blogId) {
    return this.http.post(`${environment.base_url}/blog/upload`, {ids:ids, blogId:blogId});
  }
}
