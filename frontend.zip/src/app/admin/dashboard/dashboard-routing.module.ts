import { PagesResolverService } from './../pages/services/pages-resolver.service';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from './../../core/services/auth-guard.service';

import { DashboardComponent } from './dashboard.component';
import { BeautyServicesListComponent } from './../beauty-services/components/beauty-services-list/beauty-services-list.component';
import { BeautyServicesFormComponent } from './../beauty-services/components/beauty-services-form/beauty-services-form.component';
import { BeautyServicesImagesComponent } from './../beauty-services/components/beauty-services-images/beauty-services-images.component';

import { BlogImagesComponent } from './../blog/components/blog-images/blog-images.component';
import { BlogFormComponent } from './../blog/components/blog-form/blog-form.component';
import { BlogListComponent } from './../blog/components/blog-list/blog-list.component';

import { PagesListComponent } from './../pages/components/pages-list/pages-list.component';
import { PagesFormComponent } from './../pages/components/pages-form/pages-form.component';

const routes: Routes = [
  { path: '' , component: DashboardComponent,
  canActivate: [AuthGuardService],
  children: [
    { path: 'services', component: BeautyServicesListComponent, canActivateChild: [AuthGuardService]},
    { path: 'services/add', component: BeautyServicesFormComponent, canActivateChild: [AuthGuardService]},
    { path: 'services/edit/:id', component: BeautyServicesFormComponent, canActivateChild: [AuthGuardService]},
    { path: 'services/images/:id', component: BeautyServicesImagesComponent, canActivateChild: [AuthGuardService]},

    { path: 'blog', component: BlogListComponent, canActivateChild: [AuthGuardService]},
    { path: 'blog/add', component: BlogFormComponent, canActivateChild: [AuthGuardService]},
    { path: 'blog/edit/:id', component: BlogFormComponent, canActivateChild: [AuthGuardService]},
    { path: 'blog/images/:id', component: BlogImagesComponent, canActivateChild: [AuthGuardService]},

    { path: 'pages', component: PagesListComponent, canActivateChild: [AuthGuardService]},
    { path: 'pages/add', component: PagesFormComponent, canActivateChild: [AuthGuardService]},
    { path: 'pages/edit/:id', component: PagesFormComponent, resolve: {
      pagesArray: PagesResolverService  // get the data before navigation byid
    }, canActivateChild: [AuthGuardService]}
  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
