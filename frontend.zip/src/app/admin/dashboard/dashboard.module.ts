import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MaterialModule } from './../../shared/material.module';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { ToolbarComponent } from './components/toolbar/toolbar.component';

import { BeautyServicesModule } from './../beauty-services/beauty-services.module';
import { BlogModule } from './../blog/blog.module';
import { PagesModule } from './../pages/pages.module';

import { DeleteDialogBoxComponent } from './../helper/delete-dialog-box/delete-dialog-box.component';

@NgModule({
  declarations: [
    DashboardComponent,
    SideNavComponent,
    ToolbarComponent,
    DeleteDialogBoxComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    BeautyServicesModule,
    BlogModule,
    PagesModule,
    MaterialModule
  ],
  entryComponents: [DeleteDialogBoxComponent]
})
export class DashboardModule { }
