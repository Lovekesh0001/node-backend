import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { JwtService } from './../../../../core/services/jwt.service';
import { ErrorHandlerService } from './../../../helper/error-handler.service';
import { AuthService } from './../../../../core/services/auth.service';

@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.css']
})
export class ToolbarComponent implements OnInit {

  @Output() toggleSidenav = new EventEmitter<void>();
  constructor(private jwtService: JwtService,
              private router: Router,
              private errorHandlerService: ErrorHandlerService,
              private authService: AuthService) { }

  ngOnInit(): void {
  }

  logOut(){
    this.authService.logout()
      .subscribe(data => {
        //console.log(data);
      }, err =>{
        this.errorHandlerService.error(err);
      });
    this.jwtService.destroyToken();
    this.router.navigateByUrl("/");
    this.errorHandlerService.success("Successfully logged out", "Success");
  }

}
