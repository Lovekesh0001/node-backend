import { Pages, PagesArray } from './../../models/pages';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';


import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import {MatSnackBar} from '@angular/material/snack-bar';
import { ErrorHandlerService } from 'src/app/admin/helper/error-handler.service';
import { PagesService } from './../../services/pages.service';

@Component({
  selector: 'app-pages-form',
  templateUrl: './pages-form.component.html',
  styleUrls: ['./pages-form.component.css']
})
export class PagesFormComponent implements OnInit {
  public Editor = ClassicEditor;
  imageUrl = 'assets/images/upload.png';
  image: File = null;
  id: string = '';
  addUpdateName = 'Add Pages';
  breadcrumb = [];
  submitted = false;
  oldImage = '';

   model = {
    title: '',
    description: '',
  };

  constructor(private snackBar: MatSnackBar,
              private errorHandlerService: ErrorHandlerService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private pagesService:PagesService) { }

  ngOnInit(): void {
      this.getParamsId();
      this.breadcrumb = [{name1:"Admin", link1:"/admin"},{name1:"Pages Listings", link1:"/admin/pages"},{name1:this.addUpdateName, link1:""}]
  }

  getParamsId(){
     this.activatedRoute.params.subscribe(params => {
      this.id = params['id'];
      if(this.id){
        this.setServiceToForm();
        this.addUpdateName = 'Update Service';
      }
     });
  }

  setServiceToForm(){
    this.activatedRoute.data.subscribe((data: {pagesArray:PagesArray}) => {
      if(data.pagesArray.status == 'success'){
           this.model = data.pagesArray.data;
           if(data.pagesArray.imageUrl){
            this.imageUrl = data.pagesArray.imageUrl;
            this.oldImage = data.pagesArray.imageUrl;
           }
         }else{
           this.errorHandlerService.success(data.pagesArray.message, data.pagesArray.status);
           this.router.navigateByUrl("/admin/pages");
         }
    });
  }

  handleFileUpload(file: FileList) {
    this.image = file.item(0);
    // Show image
    const reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
    reader.readAsDataURL(this.image);
  }

    onSubmit(form: NgForm) {
      this.submitted = true;
      if(this.id){
        this.update(form.value);
      }else{
        this.create(form.value);
      }
    }

    create(formvalue){
       this.pagesService.createPages(formvalue, this.image)
          .subscribe(data => {
            this.errorHandlerService.success(data.message, data.status);
            if(data.status == 'success'){
              this.router.navigateByUrl("/admin/pages");
            }
          },
          err => {
          this.errorHandlerService.error(err);
          });
    }

    private update(formvalue) {
      this.pagesService.updatePages(this.id, formvalue, this.image, this.oldImage)
        .subscribe(data => {
         this.errorHandlerService.success(data.message, data.status);
         if(data.status == 'success'){
            this.router.navigateByUrl("/admin/pages");
         }
      }, err => {
        this.errorHandlerService.error(err);
      });
  }

}
