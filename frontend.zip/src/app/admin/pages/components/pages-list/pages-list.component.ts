import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { ErrorHandlerService } from './../../../helper/error-handler.service';
import { MatDialog } from '@angular/material/dialog';
import { PagesService } from './../../services/pages.service';
import { Pages } from './../../models/pages';
import { DeleteDialogBoxComponent } from './../../../helper/delete-dialog-box/delete-dialog-box.component';

@Component({
  selector: 'app-pages-list',
  templateUrl: './pages-list.component.html',
  styleUrls: ['./pages-list.component.css']
})
export class PagesListComponent implements OnInit {
  breadcrumb = [{name1:"Admin", link1:"/admin"},{name1:"Pages Listings", link1:"/admin/pages"}];
  displayedColumns = ['title', 'added', 'updated', 'action'];
  dataSource: Pages[] = [];
  // pagination
  length = 0;
  page = 1;
  perPage = 10;
  sortField = '';
  sortDir = '';
  isDataLoading = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private pagesService:PagesService,
              public dialog: MatDialog,
              private errorHandlerService: ErrorHandlerService,) { }

  ngOnInit(): void {
    this.getPages(this.page, this.perPage, this.sortField, this.sortDir, '');
  }

   getPages(page, perPage, sortField, sortDir, filter) {
    this.pagesService.getPages(page, perPage, sortField, sortDir, filter)
                              .subscribe(data => {
                                this.isDataLoading = false;
                                if(data){
                                  this.dataSource = data.docs;
                                  this.length = data.total;
                                }
                              }, err => {
                                this.errorHandlerService.error(err);
                              });
  }

  ngAfterViewInit() {
    this.paginator.page.subscribe(data => {
      this.isDataLoading = true;
      this.getPages(this.page=++data.pageIndex, this.perPage=data.pageSize, this.sortField, this.sortDir, '');
    });

    this.sort.sortChange.subscribe(data => {
      this.paginator.pageIndex= 0;
      this.isDataLoading = true;
      this.getPages(1, 10, data.active, data.direction,'');
    });
  }

  filterData(value: string){
    this.paginator.pageIndex= 0;
      this.isDataLoading = true;
      this.getPages(1, 10, '', '', value.trim());
  }

  deleteDialog(id: string) {
    const dialogRef = this.dialog.open(DeleteDialogBoxComponent, {
      data:{
        message: 'Are you sure want to delete?',
        confirmButtonText: 'Delete',
        cancelButtonText: 'No Thanks',
        id:id
      },
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(id => {
      if(id) {
        this.deleteRowData(id);
      }
    });
  }

  deleteRowData(id){
    this.pagesService.deletePagesById(id)
        .subscribe((data: any) => {
         if(data.status == 'success'){
            this.length = this.length-1;
            this.dataSource = this.dataSource.filter((value,key)=>{
              return value._id != id;
            });
         }
        this.errorHandlerService.success(data.message, data.status);
        }, err => {
          this.errorHandlerService.error(err);
        });
  }

}
