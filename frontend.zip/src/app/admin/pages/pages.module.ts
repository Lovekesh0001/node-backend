import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';
import { MaterialModule } from './../../shared/material.module';

import { PagesListComponent } from './components/pages-list/pages-list.component';
import { PagesFormComponent } from './components/pages-form/pages-form.component';

import { PagesService } from './services/pages.service';
import { PagesResolverService } from './services/pages-resolver.service';

@NgModule({
  declarations: [PagesListComponent, PagesFormComponent],
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule
  ],
  providers: [PagesService, PagesResolverService]
})
export class PagesModule { }
