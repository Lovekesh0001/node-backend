export class Pages {
    _id: string;
    title: string;
    description: string;
    image: string;
    added: Date;
    updated: Date;
}

export class PagesArray{
    status: string;
    message: string;
    data: Pages;
    imageUrl: string;
}

export class PagesPaginate {
    docs: Pages[];
    total: number;
    limit: number;
    page: number;
    pages: number;
}

