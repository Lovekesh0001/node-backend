import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from './../../../../environments/environment';

import { Pages, PagesArray, PagesPaginate } from "./../models/pages";

@Injectable({
  providedIn: 'root'
})
export class PagesService {

  constructor(private http: HttpClient) { }

  getPages(page, perPage, sortField, sortDir, filter):Observable<PagesPaginate> {
    let queryString = `${environment.base_url}/pages?page=${page}&perPage=${perPage}`;
    if(sortField && sortDir){
      queryString = `${queryString}&sortField=${sortField}&sortDir=${sortDir}`;
    }
    if(filter){
      queryString = `${queryString}&filter=${filter}`;
    }
    return this.http.get<PagesPaginate>(queryString);
  }

  deletePagesById(id):Observable<Pages[]> {
    return this.http.delete<Pages[]>(`${environment.base_url}/pages/${id}`);
  }

  createPages(data, image): Observable<PagesArray>{
    var formData: any = new FormData();
    formData.append("title", data.title);
    formData.append("description", data.description);
    formData.append("image", image);
    return this.http.post<PagesArray>(`${environment.base_url}/pages`, formData);
  }

  updatePages(id: string, data, image, oldImage):Observable<PagesArray> {
    var formData: any = new FormData();
    formData.append("title", data.title);
    formData.append("description", data.description);
    formData.append("image", image);
    formData.append("oldImage", oldImage);
    return this.http.put<PagesArray>(`${environment.base_url}/pages/${id}`, formData);
  }

  getPageById(id):Observable<PagesArray> {
    return this.http.get<PagesArray>(`${environment.base_url}/pages/${id}`);
  }
}
