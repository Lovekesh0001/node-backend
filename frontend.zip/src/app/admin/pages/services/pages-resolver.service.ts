import { PagesService } from './pages.service';
import { Pages, PagesArray } from './../models/pages';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Router, ActivatedRoute } from "@angular/router";
import { take } from "rxjs/internal/operators/take";
import { map } from "rxjs/internal/operators/map";

@Injectable({
  providedIn: 'root'
})
export class PagesResolverService implements Resolve<PagesArray> {

  constructor(private pagesService: PagesService,private router: Router) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<PagesArray> {
    let id = route.paramMap.get('id');
    return this.pagesService.getPageById(id)
      .pipe(
        take(1),
        map(data => {
          if(data){
            return data;
          }else{
            this.router.navigateByUrl("/admin/pages");
            return null;
          }
        })
      )
  }
}
