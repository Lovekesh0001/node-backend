import express from 'express';
import { restRouter } from './api';
import { setGlobalMiddleware } from './api/middlewares/global-middleware';
import  errorHandler from './api/middlewares/error';

require('./config/config');
require('./config/db.js');
var path = require('path');


const app = express();
// global middlewares
setGlobalMiddleware(app);

// routes
app.use('/api', restRouter);

//middleware error handler
app.use(errorHandler.errorHandler);

//middleware error page not found or route not found
app.use(errorHandler.routeNotFoundErrorHandler);


//start server
app.listen(process.env.PORT, () => console.log(`server started at port : ${process.env.PORT}`));
