import mongoose from 'mongoose';

mongoose.Promise = global.Promise;
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false, useCreateIndex: true, useCreateIndex: true }, (err) => {
    if(!err){
        console.log('MongoDB connection succeeded');
    }else{
        console.log('error in mongodb connection :' + JSON.stringify(err, undefined, 2));
    }
});