
export const bookappointmentEmailTemplate = data => {
    return `<tr>
   <td valign="top" height="100"></td>
</tr>
<tr>
   <td valign="top" align="center" style="font-family:'Roboto',Arial,sans-serif;font-size:18px;color:#34495e;font-weight:bold">Hii Admin, ${data.user.name} sent you the booking appointment</td>
</tr>
<tr>
   <td valign="top" height="10"></td>
</tr>
<tr>
<td valign="top" align="center">
<table width="400" align="center" border="0" cellspacing="0" cellpadding="0">
    <tbody>
        <tr>
            <td valign="top" align="center" style="font-family:'Roboto',Arial,sans-serif;font-size:12px;color:#34495e;letter-spacing:-0.05px;font-weight:normal">
            Details for the appointment</td>
        </tr>
        <tr>
            <td valign="top" height="5"></td>
        </tr>
        <tr>
            <td valign="top" align="center">
            <table width="100%" align="center" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                <tbody>
                    <tr>
                        <td style="padding: 10px 0;"><b>Name:</b> ${data.user.name}</td>
                    </tr>   

                    <tr>
                        <td style="padding: 10px 0;"><b>Email:</b> ${data.user.email}</td>
                    </tr>

                    <tr>
                        <td style="padding: 10px 0;"><b>Phone Number: </b> ${data.user.phonenumber}</td>
                    </tr>
                    
                    <tr>
                        <td style="padding: 10px 0;"><b>Service Name: </b> ${data.user.servicename}</td>
                    </tr>

                    <tr>
                        <td style="padding: 10px 0;"><b>Message: </b> ${data.user.message}</td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
        <tr>
            <td valign="top" height="15"></td>
        </tr>
    </tbody>
</table>
</td>
</tr>
<tr>
   <td valign="top" height="100"></td>
</tr>`;
};