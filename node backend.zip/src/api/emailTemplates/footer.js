require('../../config/config');
export const Footer = () => {
    return `<tr>
                                 <td valign="top" bgcolor="#34495E" align="center">
                                    <table width="296" align="center" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                       <tbody>
                                          <tr>
                                             <td valign="top" height="15"></td>
                                          </tr>
                                          <tr>
                                             <td valign="top" height="14"></td>
                                          </tr>
                                          <tr>
                                             <td valign="top" align="center">
                                                <table width="194" align="center" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                                   <tbody>
                                                      <tr>
                                                         <td width="63"><a href="${process.env.FRONTEND_URI}/contact-us" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:10px;color:#ffffff;text-align:left;font-weight:normal;text-decoration:none" target="_blank" >Contact us</a></td>
                                                         <td width="1" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:9px;color:#ffffff;text-align:left;font-weight:normal">|</td>
                                                         <td width="44" align="center"><a href="${process.env.FRONTEND_URI}/terms-conditions" align="center" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:10px;color:#ffffff;font-weight:normal;text-decoration:none" target="_blank" >T&amp;C </a></td>
                                                         <td width="16" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:9px;color:#ffffff;text-align:left;font-weight:normal">|</td>
                                                         <td width="68"><a href="${process.env.FRONTEND_URI}/privacy-policy" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:10px;color:#ffffff;font-weight:normal;text-decoration:none" target="_blank" >Privacy Policy</a></td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td valign="top" height="17"></td>
                                          </tr>
                                          <tr>
                                             <td valign="top" align="center">
                                                <table width="144" align="center" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                                   <tbody>
                                                      <tr>
                                                         <td width="56" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:10px;color:#ffffff;text-align:left;font-weight:normal;text-decoration:none;letter-spacing:-0.04px">Follow us:</td>
                                                         <td width="32"><a href="" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:10px;color:#ffffff;text-align:left;font-weight:normal" target="_blank" ><img src="https://static.jeevansathi.com/images/jspc/commonimg/fb.png" width="20" height="20" alt="Facebook" class="CToWUd"></a></td>
                                                         <td width="32"><a href="" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:10px;color:#ffffff;text-align:left;font-weight:normal" target="_blank" ><img src="https://static.jeevansathi.com/images/jspc/commonimg/yt.png" width="19" height="20" alt="Youtube" class="CToWUd"></a></td>
                                                         <td width="20"><a href="" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:10px;color:#ffffff;text-align:left;font-weight:normal" target="_blank" ><img src="https://static.jeevansathi.com/images/jspc/commonimg/tw.png" width="20" height="20" alt="Twitter" class="CToWUd"></a></td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td valign="top" height="9"></td>
                                          </tr>
                                          <tr>
                                             <td valign="top" height="1" bgcolor="#51606e"></td>
                                          </tr>
                                          <tr>
                                             <td valign="top" height="4"></td>
                                          </tr>
                                          <tr>
                                             <td valign="top" align="center">
                                                <table width="100%" align="center" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;min-width:270px">
                                                   <tbody>
                                                      <tr>
                                                         <td valign="top" align="center" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:10px;line-height:11px;color:#bfbfbf;font-weight:normal;text-decoration:none;letter-spacing:-0.04px">You have received this mail because your e-mail ID is registered with Jeevansathi.com.  <br></td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td valign="top" height="12"></td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr><tr>
                <td valign="top" height="80"></td>
            </tr></tbody>
                </table>
                    </td>
                       </tr>
                        </tbody>
                          </table>
                           </td>
                            </tr>
                              </tbody>
                                </table>`;
}