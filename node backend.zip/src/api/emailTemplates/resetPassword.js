export const resetPassword = data => {
    return `<tr>
   <td valign="top" height="100"></td>
</tr>
<tr>
   <td valign="top" align="center" style="font-family:'Roboto',Arial,sans-serif;font-size:18px;color:#34495e;font-weight:bold">Hii, ${data.user.fullName}, Please click on the link to reset password.</td>
</tr>
<tr>
   <td valign="top" height="10"></td>
</tr>
<tr>
   <td valign="top" align="center">
      <table width="244" align="center" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
         <tbody>
            <tr>
               <td align="center" height="43" bgcolor="#D9475C"><a href="${data.resetPasswordLink}" style="font-family:'Roboto',Helvetica,Arial,sans-serif;font-size:13px;color:#ffffff;font-weight:500;text-decoration:none;text-transform:uppercase;display:block;line-height:43px" target="_blank" >Reset Password</a></td>
            </tr>
         </tbody>
      </table>
   </td>
</tr>
<tr>
   <td valign="top" height="100"></td>
</tr>`;
};