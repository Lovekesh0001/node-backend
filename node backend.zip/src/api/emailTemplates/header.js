require('../../config/config');
export const Header = () => {
    return `<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F8F8F8" style="border-collapse:collapse">
   <tbody>
      <tr>
         <td valign="top" align="center">
            <table align="center" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" style="max-width:500px;border-collapse:collapse">
               <tbody>
                  <tr>
                     <td valign="top" width="500">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                           <tbody>
                           <tr>
                                 <td valign="top" height="80"></td>
                              </tr>
                           <tr>
   <td valign="top" align="center" bgcolor="#d9475c">
      <table width="91%" align="center" border="0" cellspacing="0" cellpadding="2" style="border-collapse:collapse">
         <tbody>
            <tr>
               <td valign="top" height="10"></td>
            </tr>
            <tr>
               <td valign="top">
                  <table width="86" align="left" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                     <tbody>
                        <tr>
                           <td><a href="${process.env.FRONTEND_URI}" style="color:#f7f6f6;width:inherit;text-decoration:none" target="_blank"><img src="https://ci6.googleusercontent.com/proxy/BJMJZ1YQ-1v7Ci1MELp-BH36aC90Q5XPyVSQF-F7HQELvwMDoT7sq0531sG8vAEGwJXXa8Zkh62IUIS0i-2KOzay5JQniPuvonz1syAluMblzWXM0ueV=s0-d-e1-ft#https://static.jeevansathi.com/images/jspc/commonimg/logoBefound.png" alt="Jeevansathi.com" width="90" height="24" class="CToWUd"></a></td>
                        </tr>
                     </tbody>
                  </table>
               </td>
            </tr>
            <tr>
               <td valign="top" height="10"></td>
            </tr>
         </tbody>
      </table>
   </td>
</tr>`;
}