import express from 'express';
import {pagesRouter} from './resources/pages';
import {servicesRouter} from './resources/services';
import {userRouter} from './resources/user';
import {blogRouter} from './resources/blog';
import {socialLoginRouter} from './resources/socialLogin';
import {frontendRouter} from './resources/frontend';

export const restRouter = express.Router();
restRouter.use('/pages', pagesRouter);
restRouter.use('/services', servicesRouter);
restRouter.use('/blog', blogRouter);
restRouter.use('/users', userRouter);
restRouter.use('/auth', socialLoginRouter);
restRouter.use('/', frontendRouter);