import passport from 'passport';
import GoogleStrategy from 'passport-google-oauth';
import User from '../resources/user/user.model';

// Use the GoogleStrategy within Passport.
//   Strategies in passport require a `verify` function, which accept
//   credentials (in this case, a token, tokenSecret, and Google profile), and
//   invoke a callback with a user object.

export const configureGoogleStrategy = () => {

passport.use(
    new GoogleStrategy.OAuth2Strategy({
        clientID: process.env.GOOGLE_CLIENT_ID,
        clientSecret: process.env.GOOGLE_CLIENT_SECTRET,
        callbackURL: process.env.GOOGLE_CALLBACKURL
    },
  async (accessToken, refreshToken, profile, done) => {
     try {
          // find the user by google id
          const user = await User.findOne({ 'google.id': profile.id });
          if (user) {
            // if user exit
            // return this user
            return done(null, user);
          }

          // otherwise create the user with google
          const newUser = new User({});
          // save accessToken, email, displayName, id
          newUser.google.id = profile.id;
          newUser.google.token = accessToken;
          newUser.google.displayName = profile.displayName;
          newUser.google.email = profile.emails[0].value;
          newUser.isVerify = 1;
          newUser.image = profile.photos[0].value;
          newUser.lastLogin = new Date();
          newUser.added = new Date();
          newUser.fullName = profile.displayName;
          await newUser.save();
          done(null, newUser);
        } catch (err) {
          return done(err);
        }
  }
));
};
