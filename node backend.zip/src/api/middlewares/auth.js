import passport from 'passport';
import asyncAwaitHandler from './asyncAwait';

exports.authorize = (...roles) => asyncAwaitHandler(async (req, res, next) => {
    if (!roles.includes(req.currentUser.userType)) {
        return res.json({status: 'error', message: `User role ${req.currentUser.userType} is not authorized to access this route`});
    }
    next();
});