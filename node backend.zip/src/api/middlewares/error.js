const ErrorResponse = require('../helpers/errorResponse');

export default {
    errorHandler(error, req, res, next){
          // Mongoose bad ObjectId
        if (error.name === 'CastError') {
            error.message = 'Please provide a valid id';
        }

        // Mongoose duplicate key
        if (error.code === 11000) {
            error.message = 'Duplicate field value entered';
        }

        if(error.name === 'ValidationError'){
            var valErrors = [];
            Object.keys(error.errors).forEach(key =>{ valErrors.push(error.errors[key].message)});
            error.message = valErrors.join(", ");
        }
      
        res.status(error.statusCode || 200).json({ status: 'error', message: error.message || 'Server Error'
  });
    },
    routeNotFoundErrorHandler(req, res, next){
        res.status(404).json({ status:'error', message: 'Page Not Founds'});
    }
};