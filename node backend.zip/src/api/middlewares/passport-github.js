import passport from 'passport';
import GithubStrategy from 'passport-github';
import User from '../resources/user/user.model';

// Use the GoogleStrategy within Passport.
//   Strategies in passport require a `verify` function, which accept
//   credentials (in this case, a token, tokenSecret, and Google profile), and
//   invoke a callback with a user object.

export const configureGithubStrategy = () => {

passport.use(
    new GithubStrategy.Strategy({
        clientID: process.env.GITHUB_KEY,
        clientSecret: process.env.GITHUB_SECRET,
        callbackURL: process.env.GITHUB_CALLBACK
    },
  async (accessToken, refreshToken, profile, done) => {
     try {
          // find the user by github id
          const user = await User.findOne({ 'github.id': profile.id });
          if (user) {
            // if user exit
            // return this user
            return done(null, user);
          }

          // otherwise create the user with google
          const newUser = new User({});
          // save accessToken, email, displayName, id
          newUser.github.id = profile.id;
          newUser.github.token = accessToken;
          newUser.github.displayName = profile.displayName;
          newUser.github.email = profile.emails[0].value;
          newUser.isVerify = 1;
          newUser.image = profile.photos[0].value;
          newUser.lastLogin = new Date();
          newUser.added = new Date();
          newUser.fullName = profile.displayName;
          await newUser.save();
          done(null, newUser);
        } catch (err) {
          return done(err);
        }
  }
));
};
