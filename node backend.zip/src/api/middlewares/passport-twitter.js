import passport from 'passport';
import TwitterStrategy from 'passport-twitter';
import User from '../resources/user/user.model';

// Use the GoogleStrategy within Passport.
//   Strategies in passport require a `verify` function, which accept
//   credentials (in this case, a token, tokenSecret, and Google profile), and
//   invoke a callback with a user object.

export const configureTwitterStrategy = () => {

passport.use(
    new TwitterStrategy.Strategy({
        consumerKey: process.env.TWITTER_KEY,
        consumerSecret: process.env.TWITTER_SECRET,
        callbackURL: process.env.TWITTER_CALLBACK
    },
  async (token, tokenSecret, profile, done) => {
     try {
          // find the user by twitter id
          const user = await User.findOne({ 'twitter.id': profile.id });
          if (user) {
            // if user exit
            // return this user
            return done(null, user);
          }

          // otherwise create the user with google
          const newUser = new User({});
          // save accessToken, email, displayName, id
          newUser.twitter.id = profile.id;
          newUser.twitter.token = token;
          newUser.twitter.displayName = profile.displayName;
          newUser.twitter.username = profile.username;
          newUser.isVerify = 1;
          newUser.image = profile.profile_background_image_url;
          newUser.lastLogin = new Date();
          newUser.added = new Date();
          newUser.fullName = profile.displayName;
          await newUser.save();
          done(null, newUser);
        } catch (err) {
          return done(err);
        }
  }
));
};
