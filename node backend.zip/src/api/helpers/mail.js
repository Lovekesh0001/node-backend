import nodeMailer from "nodemailer";
import htmlToText from 'html-to-text';
require('../../config/config');

var transporter = nodeMailer.createTransport({
    host: process.env.MAIL_HOST,
    port: process.env.MAIL_PORT,
    auth: {
        user: process.env.MAIL_USEREMAIL,
        pass: process.env.MAIL_PASSWORD
    }
});

exports.sendEmail = options => {
    return new Promise((resolve, reject) => {

        const text = htmlToText.fromString(options.html, {
            wordwrap: 130
        });

        const mailOptions = {
            from: options.from,
            to: options.to,
            subject: options.subject,
            text,
            html: options.html
        }
    
    transporter.sendMail(mailOptions, function (err, info) {
        if (err) {
            return reject({status: 'error', data: err});
        } else {
            return resolve({status: 'success', data: JSON.stringify(info)});
        }
    });
  });  
};