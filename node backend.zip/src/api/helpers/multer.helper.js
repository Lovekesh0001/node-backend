import multer from 'multer';
import path from 'path';
import fs from 'fs';

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        let originalUrl = req.originalUrl.split('/')[2];
        const filePath = `./uploads/${originalUrl}/`;
        fs.mkdirSync(filePath, { recursive: true }); //create folder ig=f not exists
        cb(null, filePath);
    },
    filename: function(req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

// 
const multistorage = multer.diskStorage({
    destination: function (req, file, cb) {
        let originalUrl = req.originalUrl.split('/')[2];
        const multifilePath = `./uploads/${originalUrl}/${req.params.id}/`;
        fs.mkdirSync(multifilePath, { recursive: true }); //create folder ig=f not exists
        cb(null, multifilePath);
    },
    filename: function(req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|gif/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
    if(mimetype && extname) {
        cb(null, true);
    }else{
        cb('jpeg, jpg, png, gif Images only.', false);
    }
};
//2mb
const filesize = 1024*1024*2;
exports.singleFileupload = multer({ 
    storage: storage,
    limits: {
        fileSize: filesize
    },
    fileFilter: fileFilter
}).single('image');


exports.multiFileupload = multer({ 
    storage: multistorage,
    limits: {
        fileSize: filesize
    },
    fileFilter: fileFilter
}).array('images',10);