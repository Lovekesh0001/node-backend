import mongoose from 'mongoose';
import bcryptjs from 'bcryptjs';

const UserSchema = new mongoose.Schema({
    fullName: {
        type: String
    },
    mobileNumber: {
        type: String
    },
    image: {
        type: String,
        default: '', 
    },
    userType: {
        type: String,
        enum: ['superadmin', 'client'],
        default: 'client'
    },
    isVerify: {
        type: Number,
        default: 0
    },
    lastLogin: {
        type: String,
        default: ''
    },
    added: {
        type: Date
    },
    updated: {
        type: Date
    },
    local: {
        email: {
                type: String,
                lowercase: true
            },
        password: String
    },
    google: {
        email: String,
        id: String,
        displayName: String,
        token: String,
    },
    twitter: {
        username: String,
        id: String,
        displayName: String,
        token: String,
    },
    github: {
        email: String,
        id: String,
        displayName: String,
        token: String,
    }
});

// UserSchema.pre('save', async function() {
//     if(this.isModified('password') || this.isNew){
//         const salt = await bcryptjs.genSalt();
//         const hash = await bcryptjs.hash(this.password, salt);
//         this.password = hash;
//     }
// });
export default mongoose.model("User", UserSchema);