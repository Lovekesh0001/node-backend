import User from './user.model';
import userService from './user.service';
import httpStatus from 'http-status-codes';
import bcryptjs from 'bcryptjs';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import { sendEmail } from '../../helpers/mail';
import { Header } from '../../emailTemplates/header';
import { Footer } from '../../emailTemplates/footer';
import { Registration } from '../../emailTemplates/registration';
import { resetPassword } from '../../emailTemplates/resetPassword';
import { getJWTToken, getEncryptedPassword } from '../../helpers/util';

var date = new Date();
export default {
    async signup(req, res, next) {
        try{
            const {error, value} = userService.validateCreateSchema(req.body, res);
            if (error && error.details) {
                var valErrors = [];
                Object.keys(error.details).forEach(key => valErrors.push(error.details[key].message));
                valErrors = valErrors.join(",");
                return res.json({status: 'error', message: valErrors});
            }
            const newUser = await new User();
            const salt = await bcryptjs.genSalt();
            const hash = await bcryptjs.hash(value.password, salt);
            newUser.fullName = value.fullName;
            newUser.local.email = value.email;
            newUser.local.password = hash;
            newUser.added = date;
            newUser.updated = date;

            const criteria = {
                $or: [
                    {'local.email' : value.email},
                    {'google.email' : value.email},
                    {'twitter.email' : value.email},
                    {'github.email' : value.email},
                ]
            };
            const UserEmailExists = await User.findOne(criteria);
            if(UserEmailExists){
                 return res.json({status: 'error', message: 'Email address already registered'}); 
            }else{
                const user = await newUser.save(); 
                if(user){
                    const data = {
                        user: user,
                        confimationLink: `${process.env.FRONTEND_URI}/confirmation/${user._id}`
                    }
                    
                    const mailOptions = {
                        from: "'Lovekesh singh' <lovekesh0001@gmail.com>",
                        to: value.email,
                        subject: `Registration Successfull ${process.env.BACKEND_URI}`,
                        html:  Header() + Registration(data) + Footer()
                    }
                    const email = await sendEmail(mailOptions);
                    if(email.status === 'success'){
                            return res.json({status: 'success', message: 'Thank you for the registering with us. We have sent you a verification email. Please verify your email address.'});
                    }
                }
                return res.json({status: 'error', message: 'Something went wrong'});
            }
        }catch(err){
           return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }   
    },
    async login(req, res){
        try{
            const {value} = userService.validateLoginSchema(req.body, res);
            const criteria = {
                $or: [
                    {'local.email' : value.email},
                    {'google.email' : value.email},
                    {'twitter.email' : value.email},
                    {'github.email' : value.email},
                ]
            };
            const user  = await User.findOne(criteria);

            if(!user){
                return res.json({status: 'error', message: 'Invalid email or password'}); 
            }
            const matchPassword = await bcryptjs.compare(value.password, user.local.password);
    
            if(!matchPassword){
                return res.json({status: 'error', message: 'Invalid credentials'}); 
            }
            if(user.isVerify !==1){
                return res.json({status: 'error', message: 'we have sent you a verification email to activate your account, Please activate your account or contact to admin'}); 
            }
            // update last login details
            await User.update({_id: user._id}, {lastLogin: date});
            const jwtToken = jwt.sign({id: user._id}, process.env.SECRET_LOGIN_KEY, {expiresIn: '1d'});
            return res.json({status: 'success',message:"Successfully logged in", token: jwtToken});
        }catch(err){
            return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    async confimation(req, res){
        try{
            const id = mongoose.Types.ObjectId.isValid(req.params.id);
            if(id === false){
                return res.status(httpStatus.OK).json({status: 'error', message: 'Not a valid Link'});
            }
            const user = await User.findById({_id:req.params.id});
            if(user){
                if(user.isVerify === 1){
                    return res.json({status: 'error', message: 'Already verified, Please login'});
                }else{
                    const updateVerifyUser = await User.update({_id:req.params.id}, {isVerify:1}, {new: true});
                    if(updateVerifyUser.nModified === 1){
                        return res.json({status: 'success', message: 'you have successfully verified, Please login.'});
                    }else{
                         return res.json({status: 'error', message: 'Something went wrong'});   
                    }
                }
            }
            return res.json({status: 'error', message: 'User not exists'});
        }catch(err){
            return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    async forgotPassword(req, res){
        try{
            const {value} = userService.validateForgotPasswordSchema(req.body, res);
            const criteria = {
                $or: [
                    {'local.email' : value.email},
                    {'google.email' : value.email},
                    {'twitter.email' : value.email},
                    {'github.email' : value.email},
                ]
            };
            const user  = await User.findOne(criteria);
            if(user){
                const token = getJWTToken({id:user._id});
                    const data = {
                        user: user,
                        resetPasswordLink: `${process.env.FRONTEND_URI}/reset-password/${token}`
                    }
                    
                    const mailOptions = {
                        from: "'Lovekesh singh' <lovekesh0001@gmail.com>",
                        to: value.email,
                        subject: `Reset Password ${process.env.BACKEND_URI}`,
                        html:  Header() + resetPassword(data) + Footer()
                    }
                    const email = await sendEmail(mailOptions);
                    if(email.status === 'success'){
                            return res.json({status: 'success', message: 'We have sent you a reset password link to your email address'});
                    }
                }
                return res.json({status: 'error', message: 'Email address not exists'});
        }catch(err){
            return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    async resetPassword(req, res){
        try{
            //console.log(req); return false;
            const {value} = userService.validateResetPasswordSchema(req.body, res);
            const user = await User.findById(req.currentUser._id);

            const sanitizedUser = userService.getUser(user);
            if(!user.local.email){
                user.local.email = sanitizedUser.email;
            }
            const hash = await getEncryptedPassword(value.password);
            user.local.password = hash;
            const newPass = await user.save();
            if(newPass){
              return res.json({status: 'success', message: 'Successfully changed the password , Please login'});
            }
            return res.json({status: 'error', message: 'Something went wrong'});           
        }catch(err){
            return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    }
}