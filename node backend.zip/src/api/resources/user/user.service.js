import Joi from 'joi';

export default {
    validateCreateSchema(body, res) {
        const schema = Joi.object().options({ abortEarly: false }).keys({
        fullName: Joi.string().required().error(() => { return { message: 'Full Name is required '} }),
        email: Joi.string().required().email().error(() => { return { message: ' Email is required and should be valid email'} }),
        password: Joi.string().required().error(() => { return { message: ' Password is required '} }),
        confirmPassword: Joi.string().required().error(() => { return { message: ' Confirm Password is required '} })
        });
        const { error, value } = Joi.validate(body, schema);
        return {error, value};
    },
    validateLoginSchema(body, res) {
        const schema = Joi.object().options({ abortEarly: false }).keys({
        email: Joi.string().required().email().error(() => { return { message: 'Email is required and should be valid email address'} }),
        password: Joi.string().required().error(() => { return { message: ' Password is required '} }),
        });
        const { error, value } = Joi.validate(body, schema);
        if (error && error.details) {
            var valErrors = [];
            Object.keys(error.details).forEach(key => valErrors.push(error.details[key].message));
            valErrors = valErrors.join(",");
            return res.json({status: 'error', message: valErrors});
        }
        return {value};
    },
    validateForgotPasswordSchema(body, res) {
        const schema = Joi.object().options({ abortEarly: false }).keys({
        email: Joi.string().required().email().error(() => { return { message: 'Email is required and should be valid email address'} }),
        });
        const { error, value } = Joi.validate(body, schema);
        if (error && error.details) {
            var valErrors = [];
            Object.keys(error.details).forEach(key => valErrors.push(error.details[key].message));
            valErrors = valErrors.join(",");
            return res.json({status: 'error', message: valErrors});
        }
        return {value};
    },
    validateResetPasswordSchema(body, res) {
        const schema = Joi.object().options({ abortEarly: false }).keys({
            password: Joi.string().required().error(() => { return { message: ' Password is required '} }),
            confirmPassword: Joi.string().required().error(() => { return { message: ' Confirm Password is required '} })
        });
        const { error, value } = Joi.validate(body, schema);
        if (error && error.details) {
            var valErrors = [];
            Object.keys(error.details).forEach(key => valErrors.push(error.details[key].message));
            valErrors = valErrors.join(",");
            return res.json({status: 'error', message: valErrors});
        }
        return {value};
    },
    getUser(user) {
        const rsp = {};
        if (user.local.email) {
            rsp.name = user.fullName;
            rsp.email = user.local.email;
        }
        if (user.google.email) {
            rsp.name = user.fullName;
            rsp.email = user.google.email;
        }
        if (user.github.email) {
            rsp.name = user.fullName;
            rsp.email = user.github.email;
        }
        if (user.twitter.email) {
            rsp.name = user.fullName;
            rsp.email = user.twitter.email;
        }
        return rsp;
  }
}