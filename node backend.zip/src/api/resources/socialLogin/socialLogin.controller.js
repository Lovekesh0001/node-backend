import jwt from 'jsonwebtoken';

export default {
  sendJWTToken(req, res) {
    const token = jwt.sign({ id: req.currentUser._id }, process.env.SECRET_LOGIN_KEY, {
      expiresIn: '1d',
    });
    res.redirect(`${process.env.FRONTEND_URI}/admin/?token=${token}`);
  },
  authenticate(req, res) {
    return res.send(true);
  },
  logout(req, res) {
    req.logout(); // remove the session and remove req.currentUser;
    return res.json({ success: true });
  },
};