import express from 'express';
import passport from 'passport';
import socialLoginController from './socialLogin.controller';

export const socialLoginRouter = express.Router();

socialLoginRouter.get(
  '/google',
  passport.authenticate('google', {
    scope: ['profile', 'email'],
  })
);

// GET /auth/google/callback
//   Use passport.authenticate() as route middleware to authenticate the
//   request.  If authentication fails, the user will be redirected back to the
//   login page.  Otherwise, the primary route function function will be called,
//   which, in this example, will redirect the user to the home page.
socialLoginRouter.get(
  '/google/callback',
  passport.authenticate('google', { failureRedirect: '/failure' }),
  socialLoginController.sendJWTToken
);

// twiiter login
socialLoginRouter.get('/twitter', passport.authenticate('twitter'));

socialLoginRouter.get(
  '/twitter/callback',
  passport.authenticate('twitter', { failureRedirect: '/failure' }),
  socialLoginController.sendJWTToken
);
// github login
socialLoginRouter.get('/github', passport.authenticate('github'));

socialLoginRouter.get(
  '/github/callback',
  passport.authenticate('github', { failureRedirect: '/failure' }),
  socialLoginController.sendJWTToken
);

//send the token and verify it
socialLoginRouter.get('/authenticate', passport.authenticate('jwt', {session: false}), socialLoginController.authenticate);

// logout the session destroy
socialLoginRouter.get('/logout', passport.authenticate('jwt', {session: false}), socialLoginController.logout);