import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';

const PagesSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    image: {
        type: String
    },
    added: {
        type: Date
    },
    updated: {
        type: Date
    }
});
PagesSchema.plugin(mongoosePaginate);
export default mongoose.model('Pages', PagesSchema);