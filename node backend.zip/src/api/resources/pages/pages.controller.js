import Pages from './pages.model';
import Joi from 'joi';
import httpStatus from 'http-status-codes';
import multerHelper from '../../helpers/multer.helper';
import fs from 'fs';
import mongoose from 'mongoose';

const filePath = './uploads/pages/';
var imageName = '';
var date = new Date();

function creatupdate (req, res, err){
    if(err){
                err = err.code === "LIMIT_FILE_SIZE" ? err.message: err;
                return res.json({status: 'error', message: err});
            }
            if(req.file){
                imageName = req.file.filename;
            }
            const schema = Joi.object().options({ abortEarly: false }).keys({
            title: Joi.string().required().error(() => { return { message: 'Title is required and should be minimum 5 character '} }).min(5),
            description: Joi.string().required().error(() => { return { message: 'Description is required '} }),
            image: Joi.string().optional().allow(''),
            oldImage: Joi.string().optional().allow('')
        });
        const { error, value } = Joi.validate(req.body, schema);
        if (error && error.details) {
            if(imageName){
                fs.unlink(filePath + imageName, function(){});
            }
            var valErrors = [];
            Object.keys(error.details).forEach(key => valErrors.push(error.details[key].message));
            valErrors = valErrors.join(",");
            return res.json({status: 'error', message: valErrors});
        }
}

export default {
    create(req, res, next) {
        multerHelper.singleFileupload(req, res, function (err) {
            creatupdate(req, res, err);
        const pages = new Pages({
            "title" : req.body.title,
            "description" : req.body.description,
            "image" : imageName,
            "added" : date,
            "updated" :date
        });
        Pages.create(pages)
      .then(data => {
          imageName = '';
          res.json({status:'success', message: 'Created successfully', data:data})})
      .catch(err => res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err));
        });
    },
    update(req, res) {
        let {id} = req.params;
         multerHelper.singleFileupload(req, res, function (err) {
            creatupdate(req, res, err);
        const pages = {};
        pages.title = req.body.title;
        pages.description = req.body.description;
        let oldImage = '';
        if(req.body.oldImage){
            oldImage = req.body.oldImage.split("/");
            oldImage = oldImage[oldImage.length-1];
        }
        if(imageName !==''){
            if (fs.existsSync(filePath + oldImage)) {
                    fs.unlink(filePath + oldImage, function(){});
            }
            pages.image = imageName;
        }
        pages.updated = date;
        Pages.findOneAndUpdate({_id: id }, pages, {new: true})
        .then(data => { 
            imageName = '';
            res.json({status: 'success', message: 'Updated Successfully', data:data})})
        .catch(err => res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err));
        });
    },
    async findAll(req, res){
        try{
            const { page=1, perPage=10, filter, sortField='added', sortDir='desc'} = req.query;
            const options = {
                //select: '_id name',
                page: parseInt(page, 10),
                limit: parseInt(perPage, 10),
            }
            if(sortField && sortDir){
                options.sort = {
                    [sortField]: sortDir
                }
            }
            const query = {};
            if(filter){
                query.title = {
                    $regex: filter
                }
            }
            const pages = await Pages.paginate(query, options);
            setTimeout(() => {
                return res.json(pages); 
            }, 1000);
        }catch(err) {
           return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    async delete(req, res) {
        try {
            const id = mongoose.Types.ObjectId.isValid(req.params.id);
            if(id === false){
                return res.status(httpStatus.OK).json({status: 'error', message: 'Id not founds!'});
            }
            const pages = await Pages.findOneAndRemove({_id:req.params.id});
            const mes = pages ? {status: 'success', message: 'Deleted successfully!'} : {status: 'error', message: 'Data not founds!'};
            return res.json(mes)
        }catch(err) {
            return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    async findOne(req, res) {
        try {
            const id = mongoose.Types.ObjectId.isValid(req.params.id);
            if(id === false){
                return res.status(httpStatus.OK).json({status: 'error', message: 'Id not founds!'});
            }
            let imageUrl = '';
            const pages = await Pages.findById({_id:req.params.id}).select("_id title description image added updated");
            if(pages.image){
                    if (fs.existsSync(filePath + pages.image)) {
                        imageUrl = process.env.IMAGE_URI+'/pages/'+pages.image;
                    }
                }
            const mes = pages ? {status: 'success', data: pages, imageUrl:imageUrl} : {status: 'error', message: 'Data not founds!'};
            return res.json(mes)
        }catch(err) {
            return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    }
};