import express from 'express';
import pagesController from './pages.controller';
import passport from 'passport';

export const pagesRouter = express.Router();

// router.post('/contact-us', contactUsController.create);
// router.get('/contact-us', contactUsController.findAll);
// router.get('/contact-us/:id', contactUsController.findOne);
// router.delete('/contact-us/:id', contactUsController.delete)
// router.put('/contact-us/:id', contactUsController.update);
pagesRouter.route('/')
              .post(passport.authenticate('jwt', {session: false}), pagesController.create)
              .get(passport.authenticate('jwt', {session: false}), pagesController.findAll);

pagesRouter.route('/:id')
               .get(passport.authenticate('jwt', {session: false}), pagesController.findOne)
               .delete(passport.authenticate('jwt', {session: false}), pagesController.delete)
               .put(passport.authenticate('jwt', {session: false}), pagesController.update);     