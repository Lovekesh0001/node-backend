import express from 'express';
import servicesController from './services.controller';
import passport from 'passport';

export const servicesRouter = express.Router();

servicesRouter.route('/')
              .post(passport.authenticate('jwt', {session: false}), servicesController.create)
              .get(passport.authenticate('jwt', {session: false}), servicesController.findAll);

servicesRouter.route('/:id')
              .get(passport.authenticate('jwt', {session: false}), servicesController.findOne)
              .delete(passport.authenticate('jwt', {session: false}), servicesController.delete)
              .put(passport.authenticate('jwt', {session: false}), servicesController.update);    

servicesRouter.route('/upload/:id').post(passport.authenticate('jwt', {session: false}), servicesController.uploadImages); 
servicesRouter.route('/upload/:id').get(passport.authenticate('jwt', {session: false}), servicesController.getUploadBeautyServiceImages); 
servicesRouter.route('/upload').post(passport.authenticate('jwt', {session: false}), servicesController.deleteUploadBeautyServiceImages);   
servicesRouter.route('/caption').post(passport.authenticate('jwt', {session: false}), servicesController.updateBeautyServiceImagesCaption); 
servicesRouter.route('/caption/:id').post(passport.authenticate('jwt', {session: false}), servicesController.updateBeautyServicesortPosition);        