import Services from './services.model';
import ServicesImages from './servicesimages.model';
import clientService from './services.service';
import httpStatus from 'http-status-codes';
import mongoose from 'mongoose';
import multerHelper from '../../helpers/multer.helper';
import fs from 'fs';
const slugify = require('slugify');

const filePath = './uploads/services/';
var sortingLet = 0;
function imgLength(data){
    sortingLet = data;
}

function getAllImages(id) {
    ServicesImages.find({seviceId: id}, function(err, img){
        if (img.length > 0){
           imgLength(img.length)
        }else{
            imgLength(0);
        }
    });
}
var date = new Date();
export default {
    async create(req, res, next) {
        try{
            const {value} = clientService.validateCreateSchema(req.body, res);
            JSON.stringify(value); 
            value["added"] = date; 
            value["updated"] = date; 
            value["slug"] = slugify(req.body.name, { lower: true });
            const services = await Services.create(value);
            return res.json({status: 'success', message: 'created successfully', data: services});
        }catch(err){
            next(err);
        }
    },
    async findAll(req, res) {
        try{
            const { page=1, perPage=10, filter, sortField='added', sortDir='desc'} = req.query;
            const options = {
                //select: '_id name',
                page: parseInt(page, 10),
                limit: parseInt(perPage, 10),
            }
            if(sortField && sortDir){
                options.sort = {
                    [sortField]: sortDir
                }
            }
            const query = {};
            if(filter){
                query.name = {
                    $regex: filter
                }
            }
            const services = await Services.paginate(query, options);
            setTimeout(() => {
                return res.json(services); 
            }, 1000);
            //const mes = services.docs ? {status: 'success', data: services.docs} : {status: 'error', message: 'Data not founds!'};
            
        }catch(err) {
           return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    async findOne(req, res) {
        try {
            const id = mongoose.Types.ObjectId.isValid(req.params.id);
            if(id === false){
                return res.status(httpStatus.OK).json({status: 'error', message: 'Id not founds!'});
            }
            const services = await Services.findById({_id:req.params.id}).select("_id name shortdescription description added");
            const mes = services ? {status: 'success', data: services} : {status: 'error', message: 'Data not founds!'};
            return res.json(mes)
        }catch(err) {
            return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    async delete(req, res) {
        try {
            const id = mongoose.Types.ObjectId.isValid(req.params.id);
            if(id === false){
                return res.status(httpStatus.OK).json({status: 'error', message: 'Id not founds!'});
            }
            const services = await Services.findOneAndRemove({_id:req.params.id});
            const mes = services ? {status: 'success', message: 'Deleted successfully!'} : {status: 'error', message: 'Data not founds!'};
            return res.json(mes)
        }catch(err) {
            return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    async update(req, res) {
        try{
            const id = mongoose.Types.ObjectId.isValid(req.params.id);
            if(id === false){
                return res.status(httpStatus.OK).json({status: 'error', message: 'Id not founds!'});
            }
            const {value} = clientService.validateCreateSchema(req.body, res);
            JSON.stringify(value); 
            value["updated"] = date; 
            value["slug"] = slugify(req.body.name, { lower: true });
            const services = await Services.findOneAndUpdate({_id:req.params.id}, value, {new:true});
            const mes = services ? {status: 'success', message: 'Updated successfully!', data:services} : {status: 'error', message: 'Data not updated!'};
            return res.json(mes)
        }catch(err) {
            return res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    uploadImages(req, res, next) {
        let {id} = req.params;
        getAllImages(id);
        multerHelper.multiFileupload(req, res, function (err) {
            if(err){
                let err1 = '';
                if(err.code === "LIMIT_FILE_SIZE"){
                    err1 = err.message;
                }else if(err.code === "LIMIT_UNEXPECTED_FILE"){
                    err1 = "Only 10 photos allowed once per upload!";
                }else{
                    err1 = err;
                }
                return res.json({status: 'error', message: err1});
                
            }
            if (!req.files) {
            return res.json({status: 'error', message: 'Images required'});
            }
            if(req.files.length > 0){
                let i = 0;
                const groupedArray = [];
                req.files.forEach(function(key, value) {
                    groupedArray.push({
                        seviceId: id,
                        name: key.filename,
                        sorting: sortingLet,
                        caption: ''
                    });
                    i++;
                    sortingLet++;
                });
                ServicesImages.create(groupedArray)
                .then(data => res.json({status: 'success', message: i+' Images uploaded successfully, Please click on the refresh gallery button.', data: data}))
                .catch(err => res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err));
      }
        });
    },
    getUploadBeautyServiceImages(req, res) {
        let {id} = req.params;
        let imageUrl = '';
        let groupedArray = [];
        ServicesImages.find({seviceId: id}).sort({sorting: 'asc'})
            .then(data => {
                if(data.length > 0){
                    for(let i=0; i< data.length;i++) {
                        if (fs.existsSync(filePath + id + '/' + data[i].name)) {
                            imageUrl = `${process.env.IMAGE_URI}/services/${id}/${data[i].name}`;
                            
                            groupedArray.push({
                                _id: data[i]._id,
                                seviceId:data[i].seviceId,
                                name: data[i].name,
                                sorting: data[i].sorting,
                                caption: data[i].caption,
                                imageUrl: imageUrl
                            });
                     }
                    }
                }
                res.json({status: 'success', message: ' Images found successfully', data: groupedArray})})
            .catch(err => res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err));
    },
    deleteUploadBeautyServiceImages(req, res){
        let ids = req.body.ids;
        let serviceId = req.body.serviceId;
        let jj = 0;
        ServicesImages.find({_id: ids})
            .then(data => {
                if(data.length > 0){
                    for(let i=0; i< data.length;i++) {
                        if (fs.existsSync(filePath + serviceId + '/' + data[i].name)) {
                            fs.unlink(filePath + serviceId + '/' + data[i].name, function(){});
                        }
                        jj++;
                    }
                    
                }
                ServicesImages.deleteMany({_id: ids}).then(data => {
                res.json({status: 'success', message: jj+' Images deleted successfully'})})
                .catch(err => res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err));
            })
    },
    updateBeautyServiceImagesCaption(req, res){
        if(req.body.captions.length > 0){
            for(var j=0; j < req.body.captions.length; j++) {
                ServicesImages.update({_id:mongoose.Types.ObjectId(req.body.captions[j].id)}, {caption:req.body.captions[j].value}, {multi: true}).
                then(data => {});
                }
            res.json({status: 'success', message: 'Captions updated successfully'})
        }else{
            res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    },
    async updateBeautyServicesortPosition(req, res) {
        try{
            const previousIndex = parseInt(req.body.previousIndex);
            const currentIndex = parseInt(req.body.currentIndex);
            const imagesid = req.body.imagesid;
            const id = req.params.id;
            const getImageId = await ServicesImages.find({sorting:currentIndex, seviceId:id});
            if(getImageId.length < 0){
                return res.json({status: 'error', message: 'Something went wrong!'});
            }
            const sortingPrevious = await ServicesImages.update({_id:getImageId[0]._id}, {sorting:previousIndex}, {new:true});
            if(sortingPrevious.nModified !== 1){
                return res.json({status: 'error', message: 'Something went wrong!'});
            }
            const sortingCurrent = await ServicesImages.update({_id:imagesid}, {sorting:currentIndex}, {new:true});
            if(sortingCurrent.nModified == 1){
                return res.json({status: 'success', message: 'Sorted successfully!'})
            }
            return res.json({status: 'error', message: 'Something went wrong!'})
        }catch(err){
            res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err);
        }
    }        
};