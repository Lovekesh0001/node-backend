import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';

const ServicesSchema = new mongoose.Schema({
    name: {
        type: String,
        unique: true,
        required: true
    },
    shortdescription: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    slug:{
         type: String,
         lower: true,
    },
    added: {
        type: Date
    },
    updated: {
        type: Date
    }
});

ServicesSchema.post('save', function(error, doc, next) {
  if (error.name === 'MongoError' && error.code === 11000) {
    next(new Error('Service name already exists, Please provide different Service name'));
  } else {
    next(error);
  }
});

ServicesSchema.plugin(mongoosePaginate);
export default mongoose.model("Services", ServicesSchema);