import mongoose from 'mongoose';

const servicesImagesSchema = new mongoose.Schema({
    seviceId: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    sorting:{
        type: Number
    },
    caption: {
        type: String
    },
    added: {
        type: Date,
        default: Date
    }
    
});
export default mongoose.model("servicesimages", servicesImagesSchema);