import Joi from 'joi';
import ServicesImages from './servicesimages.model';

export default {
    validateCreateSchema(body, res) {
        const schema = Joi.object().options({ abortEarly: false }).keys({
        name: Joi.string().required().min(3).error(() => { return { message: 'Name is required and should be minimum 3 character '} }),
        shortdescription: Joi.string().required().error(() => { return { message: 'Short Description is required '} }),
        description: Joi.string().required().error(() => { return { message: 'Description is required '} }),
        });
        const { error, value } = Joi.validate(body, schema);
        if (error && error.details) {
            var valErrors = [];
            Object.keys(error.details).forEach(key => valErrors.push(error.details[key].message));
            valErrors = valErrors.join(",");
            return res.json({status: 'error', message: valErrors});
        }
        return {value};
    }
};