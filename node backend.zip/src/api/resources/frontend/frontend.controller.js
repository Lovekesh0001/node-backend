import asyncAwaitHandler from '../../middlewares/asyncAwait';
import newsLetter from './models/newsLetter.model';
import contactUs from './models/contactUs.model';
import bookAppointment from './models/bookAppointment.model';

import { sendEmail } from '../../helpers/mail';
import { Header } from '../../emailTemplates/header';
import { Footer } from '../../emailTemplates/footer';
import { ContactUsEmailTemplate } from '../../emailTemplates/ContactUsEmailTemplate';
import { bookappointmentEmailTemplate } from '../../emailTemplates/bookappointmentEmailTemplate';

exports.newsLetter = asyncAwaitHandler(async (req, res, next) => {
            const newsetter = await newsLetter.create(req.body);
            if(!newsetter){
                next();
            }
            return res.json({status: 'success', message: 'Successfully subscribed to our newsletter services'});
});

exports.contactUs = asyncAwaitHandler(async (req, res, next) => {
            req.body.userId = req.currentUser._id;
            const contactus = await contactUs.create(req.body);
            if(!contactus){
                next();
            }
            const data = {
                user: contactus
            }
            
            const mailOptions = {
                from: "'Lovekesh singh' <lovekesh0001@gmail.com>",
                to: "lovekesh0001@gmail.com",
                subject: `Contact us message ${process.env.BACKEND_URI}`,
                html:  Header() + ContactUsEmailTemplate(data) + Footer()
            }
            const email = await sendEmail(mailOptions);
            if(email.status === 'success'){
               return res.json({status: 'success', message: 'Successfully submitted your query'});
            }
});

exports.bookAppointment = asyncAwaitHandler(async (req, res, next) => {
            req.body.userId = req.currentUser._id;
            const bookappointment = await bookAppointment.create(req.body);
            if(!bookappointment){
                next();
            }
            const data = {
                user: bookappointment
            }
            
            const mailOptions = {
                from: "'Lovekesh singh' <lovekesh0001@gmail.com>",
                to: "lovekesh0001@gmail.com",
                subject: `Booking appointment message ${process.env.BACKEND_URI}`,
                html:  Header() + bookappointmentEmailTemplate(data) + Footer()
            }
            const email = await sendEmail(mailOptions);
            if(email.status === 'success'){
               return res.json({status: 'success', message: 'Successfully submitted your booking appointment'});
            }
});