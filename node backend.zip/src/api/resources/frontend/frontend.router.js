import express from 'express';
import frontendController from './frontend.controller';
import passport from 'passport';
import {authorize} from '../../middlewares/auth';

export const frontendRouter = express.Router();

frontendRouter.route('/newsletter').post(frontendController.newsLetter);
frontendRouter.route('/contact-us').post(passport.authenticate('jwt', {session: false}), authorize('superadmin', 'client'), frontendController.contactUs);
frontendRouter.route('/book-appointment').post(passport.authenticate('jwt', {session: false}), authorize('superadmin', 'client'), frontendController.bookAppointment);