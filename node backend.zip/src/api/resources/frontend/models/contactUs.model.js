import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';

const contactUsSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: [true, 'User id is required']
  },
  name:{
    type: String,
    required: [true, 'Name is required'],
  },
  email: {
    type: String,
    trim: true,
    required: [true, 'Email is required'],
    match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email address']
  },
  phonenumber:{
    type: String,
    required: [true, 'Phone number is required and should be 10 digits'],
    trim: true,
    maxlength: [10, 'Phone number can not be more than 10 digits'],
    minlength: [10, 'Phone number can not be more than 10 digits'],
  },
  subject:{
    type: String,
    trim: true
  },
  message:{
    type: String,
    trim: true
  },
  added: {
    type: Date,
    default: Date.now
  },
});

module.exports = mongoose.model('contactus', contactUsSchema);