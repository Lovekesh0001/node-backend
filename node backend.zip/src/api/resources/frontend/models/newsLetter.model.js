import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';

const newsLetterSchema = new mongoose.Schema({
  email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true,
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email address']
    },
    added: {
        type: Date,
        default: Date.now
    },
});

newsLetterSchema.post('save', function(error, doc, next) {
  if (error.name === 'MongoError' && error.code === 11000) {
    next(new Error('You are already subscribed to our newsletter services'));
  } else {
    next(error);
  }
});

module.exports = mongoose.model('newsletter', newsLetterSchema);