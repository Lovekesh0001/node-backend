import mongoose from 'mongoose';

const blogImagesSchema = new mongoose.Schema({
    blogId: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    added: {
        type: Date,
        default: Date
    }
    
});
export default mongoose.model("blogimages", blogImagesSchema);