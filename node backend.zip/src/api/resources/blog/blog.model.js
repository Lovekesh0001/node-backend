import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';

const BlogSchema = new mongoose.Schema({
    name: {
        type: String,
        trim: true,
        unique: true,
        required: [true, 'Name is required'],
    },
    slug:{
         type: String,
         lower: true,
    },
    description: {
        type: String,
        trim: true,
        required: [true, 'Description is required'],
    },
    added: {
        type: Date,
        default: Date.now
    },
    updated: {
        type: Date,
        default: Date.now
    }
});

BlogSchema.post('save', function(error, doc, next) {
  if (error.name === 'MongoError' && error.code === 11000) {
    next(new Error('Blog name already exists, Please provide different blog name'));
  } else {
    next(error);
  }
});

BlogSchema.plugin(mongoosePaginate);
export default mongoose.model("Blog", BlogSchema);