import express from 'express';
import blogController from './blog.controller';
import passport from 'passport';
import {authorize} from '../../middlewares/auth';

export const blogRouter = express.Router(); 

blogRouter.route('/').post(passport.authenticate('jwt', {session: false}), authorize('superadmin'), blogController.create)
                     .get(passport.authenticate('jwt', {session: false}), authorize('superadmin'), blogController.findAll);

blogRouter.route('/:id').get(passport.authenticate('jwt', {session: false}), authorize('superadmin'), blogController.findOne)
                        .delete(passport.authenticate('jwt', {session: false}), authorize('superadmin'), blogController.delete)
                        .put(passport.authenticate('jwt', {session: false}), authorize('superadmin'), blogController.update);    
                        
blogRouter.route('/upload/:id').post(passport.authenticate('jwt', {session: false}), authorize('superadmin'), blogController.uploadImages);
blogRouter.route('/upload/:id').get(passport.authenticate('jwt', {session: false}), authorize('superadmin'), blogController.getUploadImages);                      