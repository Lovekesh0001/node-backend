import asyncAwaitHandler from '../../middlewares/asyncAwait';
import Blog from './blog.model';
const slugify = require('slugify');
import multerHelper from '../../helpers/multer.helper';
import BlogImages from './blogimages.model';
import fs from 'fs';

exports.create = asyncAwaitHandler(async (req, res, next) => {
    req.body.slug = slugify(req.body.name, { lower: true });
    const blog = await Blog.create(req.body);
    if(!blog){
        next();
    }
    return res.json({status: 'success', message: 'Blog added successfully'});
});

exports.findAll = asyncAwaitHandler(async (req, res, next) => {
    const { page=1, perPage=10, filter, sortField='added', sortDir='desc'} = req.query;
    const options = {
        //select: '_id name',
        page: parseInt(page, 10),
        limit: parseInt(perPage, 10),
    }
    if(sortField && sortDir){
        options.sort = {
            [sortField]: sortDir
        }
    }
    const query = {};
    if(filter){
        query.name = {
            $regex: filter
        }
    }
    const blog = await Blog.paginate(query, options);
    if(!blog){
        next();
    }
    setTimeout(() => {
        return res.json(blog); 
    }, 1000);
});

exports.findOne = asyncAwaitHandler(async (req, res, next) => {
    const blog = await Blog.findById({_id:req.params.id}).select("_id name description");
    if(!blog){
        return res.json({status: 'error', data: 'blog not founds'}); 
    }
    return res.json({status: 'success', data: blog}); 
});

exports.delete = asyncAwaitHandler(async (req, res, next) => {
    const blog = await Blog.findByIdAndRemove(req.params.id);
    if(!blog){
        return res.json({status: 'error', message: 'blog not founds'}); 
    }
    return res.json({status: 'success', message: 'Blog deleted successfully'}); 
});

exports.update = asyncAwaitHandler(async (req, res, next) => {
    req.body.slug = slugify(req.body.name, { lower: true });
    req.body.updated = new Date();
    const updatedBlog = await Blog.updateOne({_id:req.params.id}, req.body,
                                            { new: true, runValidators: true });
    if(updatedBlog.nModified === 0){
        return res.json({status: 'error', message: 'Blog not updated'});
    }  
    return res.json({status: 'success', message: 'Blog updated successfully'});
});

exports.uploadImages = asyncAwaitHandler(async (req, res, next) => {
       let {id} = req.params;
       await multerHelper.multiFileupload(req, res, function (err) {
           if (!req.files) {
            return res.json({status: 'error', message: 'Images required'});
            }
           if(err){
                let err1 = '';
                if(err.code === "LIMIT_FILE_SIZE"){
                    err1 = err.message;
                }else if(err.code === "LIMIT_UNEXPECTED_FILE"){
                    err1 = "Only 10 photos allowed once per upload!";
                }else{
                    err1 = err;
                }
                return res.json({status: 'error', message: err1});
            }
            let i = 0;
            const groupedArray = [];
            req.files.forEach(function(key, value) {
                groupedArray.push({
                        blogId: id,
                        name: key.filename
                    });
                    i++;
            });
            BlogImages.create(groupedArray)
                .then(data => res.json({status: 'success', message: i+' Images uploaded successfully, Please click on the refresh gallery button.', data: data}))
                .catch(err => res.status(httpStatus.INTERNAL_SERVER_ERROR).json(err));
       });
       
         //return res.json({status: 'success', message: 'Images uploaded'});
});

exports.getUploadImages = asyncAwaitHandler(async (req, res, next) => {
    let originalUrl = req.originalUrl.split('/')[2];
    let {id} = req.params;
    let imageUrl = '';
    let groupedArray = [];
    const blogImages = await BlogImages.find({blogId: id}).sort({added: 'asc'});
    if(blogImages.length > 0){
        for(let i=0; i< blogImages.length;i++) {
            if (fs.existsSync( `./uploads/${originalUrl}/${id}/${blogImages[i].name}`)) {
                imageUrl = `${process.env.IMAGE_URI}/${originalUrl}/${id}/${blogImages[i].name}`;
                groupedArray.push({
                                _id: blogImages[i]._id,
                                blogId:blogImages[i].blogId,
                                name: blogImages[i].name,
                                imageUrl: imageUrl
                            });
            }
        }
        res.json({status: 'success', message: ' Images found successfully', data: groupedArray});
    }
    return res.json({status: 'error', message: 'Images not found'});
});

